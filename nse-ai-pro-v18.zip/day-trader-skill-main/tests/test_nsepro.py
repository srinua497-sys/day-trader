"""Offline tests for the NSE AI PRO package. Yahoo Finance is never called: data is synthetic or faked."""
import os
import sys
import tempfile
import time
import unittest

import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
for p in (ROOT, HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

from synth import make_daily, make_intraday  # noqa: E402
from nsepro import analysis, data as D, levels, ml, reports, scanner, validate  # noqa: E402
from nsepro.signals import compute_signals  # noqa: E402

ml.MODEL_DIR = tempfile.mkdtemp()
scanner.CHECKPOINT_DIR = tempfile.mkdtemp()


def same(a, b):
    a, b = np.asarray(a), np.asarray(b)
    return np.allclose(a.astype(float), b.astype(float), equal_nan=True, rtol=1e-6, atol=1e-9)


class Causality(unittest.TestCase):
    def test_signals_never_use_future_bars(self):
        df = make_intraday(40, 15, seed=3)
        full = compute_signals(df)
        for n in (320, 555, 800):
            part = compute_signals(df.iloc[:n])
            for col in part.columns:
                self.assertTrue(same(full[col].iloc[:n], part[col]), "column %s changes when future bars are removed (n=%d)" % (col, n))

    def test_ml_features_never_use_future_bars(self):
        df = make_intraday(40, 15, seed=4)
        full = ml.build_features(df)
        n = 700
        part = ml.build_features(df.iloc[:n])
        for col in ml.FEATURES:
            self.assertTrue(same(full[col].loc[part.index], part[col]), "feature %s leaks the future" % col)


class DataLayer(unittest.TestCase):
    def _raw(self, syms):
        base = make_intraday(5, 15, seed=1)
        return {s: base * (1 + i * 0.01) for i, s in enumerate(syms)}

    def test_split_download_both_layouts(self):
        syms = ["A.NS", "B.NS"]
        raw = self._raw(syms)
        by_ticker = pd.concat(raw, axis=1)                      # (ticker, field)
        by_field = pd.concat(raw, axis=1).swaplevel(axis=1)     # (field, ticker)
        for layout in (by_ticker, by_field):
            got = D._split_download(layout, syms)
            self.assertEqual(sorted(got), syms)
            self.assertEqual(len(D.clean_frame(got["A.NS"], True)), len(raw["A.NS"]))

    def test_clean_frame_filters_hours_and_bad_rows(self):
        df = make_intraday(2, 15, seed=2, tz=False)
        pre = pd.DataFrame([[1, 2, 0.5, 1.5, 10]], columns=D.OHLCV, index=[df.index[0].normalize() + pd.Timedelta(hours=9)])
        bad = pd.DataFrame([[5, 4, 6, 5, 10]], columns=D.OHLCV, index=[df.index[0] + pd.Timedelta(days=5)])  # high < low
        out = D.clean_frame(pd.concat([pre, df, bad]), True)
        self.assertEqual(len(out), len(df))
        self.assertEqual(str(out.index.tz), D.IST)
        mins = out.index.hour * 60 + out.index.minute
        self.assertTrue(((mins >= 555) & (mins < 930)).all())

    def test_forming_bar_dropped(self):
        df = make_intraday(2, 15, seed=2)
        last = df.index[-1]
        self.assertEqual(len(D.drop_forming_bar(df, 15, now=last + pd.Timedelta(minutes=5))), len(df) - 1)
        self.assertEqual(len(D.drop_forming_bar(df, 15, now=last + pd.Timedelta(minutes=20))), len(df))


class Plans(unittest.TestCase):
    def test_levels_geometry(self):
        a = analysis.analyze("T.NS", make_intraday(40, 15, seed=5))
        b, s = a["plans"]["BUY"], a["plans"]["SELL"]
        self.assertLess(b["stop"], b["entry"]); self.assertLess(b["entry"], b["t1"]); self.assertLess(b["t1"], b["t2"]); self.assertLess(b["t2"], b["t3"])
        self.assertGreater(s["stop"], s["entry"]); self.assertGreater(s["entry"], s["t1"]); self.assertGreater(s["t1"], s["t2"]); self.assertGreater(s["t2"], s["t3"])
        for p in (b, s):
            r = p["risk"]
            self.assertAlmostEqual(abs(p["t1"] - p["entry"]), r, places=6)
            self.assertAlmostEqual(abs(p["t2"] - p["entry"]), 2 * r, places=6)
            self.assertAlmostEqual(abs(p["t3"] - p["entry"]), 3 * r, places=6)
            self.assertGreaterEqual(r, 0.8 * p["atr"] - 1e-9)
            self.assertLessEqual(r, 3 * p["atr"] + 1e-9)

    def test_high_risk_plan_is_invalidated(self):
        df = make_intraday(40, 15, seed=5)
        df.iloc[-1, df.columns.get_loc("High")] = df["Close"].iloc[-1] * 1.12   # a giant candle inflates ATR and risk
        d = compute_signals(df)
        d.loc[d.index[-1], "atr"] = d["Close"].iloc[-1] * 0.05
        p = levels.trade_plan(d, "BUY", True)
        self.assertFalse(p["valid"])
        self.assertIn("exceeds", p["invalid_reason"])

    def test_decision_waits_without_signal(self):
        df = make_intraday(40, 15, seed=6)
        a = analysis.analyze("T.NS", df)
        out = analysis.decide({"15 min": a}, "15 min")
        self.assertIn(out["decision"], ("BUY", "SELL", "WAIT"))
        if a["label"] == "No signal":
            self.assertEqual(out["decision"], "WAIT")


class Validation(unittest.TestCase):
    def test_barrier_outcomes(self):
        idx = pd.date_range("2026-09-01 09:15", periods=8, freq="15min", tz=D.IST)
        df = pd.DataFrame({"Open": 100.0, "High": 100.5, "Low": 99.5, "Close": 100.0, "Volume": 1.0, "atr": 1.0}, index=idx)
        df.loc[idx[2], "High"] = 102.0   # bar0 BUY hits +1.5 ATR on bar 2
        df.loc[idx[3], "Low"] = 98.0     # bar1 BUY: bar2 high=102 wins first
        out = validate.barrier_outcomes(df, "BUY", horizon=3)
        self.assertEqual(out.iloc[0], 1.0)
        self.assertTrue(np.isnan(out.iloc[-1]))   # outcome unknown at the end
        self.assertIn(validate.barrier_outcomes(df, "SELL", horizon=3).iloc[1], (-1.0, 0.0, 1.0))

    def test_wilson_is_conservative(self):
        self.assertLess(validate.wilson_lower(6, 10), 0.6)
        self.assertEqual(validate.wilson_lower(0, 0), 0.0)

    def test_small_samples_are_unvalidated(self):
        d = compute_signals(make_intraday(40, 15, seed=7))
        mask = pd.Series(False, index=d.index); mask.iloc[100:105] = True
        v = validate.validate_signal(d, mask, "BUY")
        self.assertEqual(v["factor"], 0.6)
        self.assertLessEqual(validate.validated_confidence(80, v), 48.0)


class MLTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.frames = {"S%d.NS" % i: make_intraday(60, 15, seed=i) for i in range(6)}
        cls.ds = ml.build_dataset(cls.frames)

    def test_labels_do_not_cross_sessions(self):
        for sym, g in self.ds.groupby("symbol"):
            g = g.sort_values("ts_ns")
            last_bars = g.groupby(g["ts"].dt.date).tail(3)
            self.assertTrue(last_bars["up3"].isna().all(), "last 3 bars of a session must have no 3-bar label")
            self.assertTrue(g.groupby(g["ts"].dt.date).tail(1)["entry_px"].isna().all())

    def test_walk_forward_is_time_ordered_and_leak_free(self):
        wf = ml.walk_forward(self.ds, "up3", "XGBoost", "15 min", n_folds=4)
        f = wf["folds"]
        for _, r in f.iterrows():
            self.assertLessEqual(r["train_end"], r["test_start"])
        self.assertTrue((f["test_start"].values[1:] >= f["test_end"].values[:-1]).all() or len(f) == 1)
        oos = wf["oos"]
        first_test = pd.to_datetime(f["test_start"].iloc[0]).tz_localize("UTC") - pd.Timedelta(days=1)
        self.assertGreater(pd.to_datetime(oos["ts_ns"].min(), utc=True), first_test)
        self.assertEqual(len(oos), wf["summary"]["oos_samples"])

    def test_random_walk_shows_no_edge(self):
        r = ml.train_and_validate(self.frames, "15 min", "up3", "Random Forest", n_folds=3, save=False)
        s = r["bundle"]["summary"]
        self.assertLess(s["oos_accuracy"], s["baseline_accuracy"] + 0.05)
        self.assertEqual(r["bundle"]["n_symbols"], 6)

    def test_save_load_predict_roundtrip(self):
        r = ml.train_and_validate(self.frames, "15 min", "bigmove", "XGBoost", n_folds=3)
        b = ml.load_bundle("15 min", "bigmove", "XGBoost")
        self.assertIsNotNone(b)
        pr = ml.predict_latest(b, {k: v for k, v in list(self.frames.items())[:2]})
        self.assertEqual(len(pr), 2)
        self.assertTrue(((pr["p_event"] >= 0) & (pr["p_event"] <= 1)).all())
        self.assertIn("lift", b)

    def test_backtest_pays_costs(self):
        wf = ml.walk_forward(self.ds, "up3", "XGBoost", "15 min", n_folds=3)
        free = ml.backtest(wf["oos"], "up3", 0.52, 0.0)["stats"]
        paid = ml.backtest(wf["oos"], "up3", 0.52, 20.0)["stats"]
        self.assertGreater(free["trades"], 0)
        self.assertAlmostEqual(free["avg_net_bps"] - paid["avg_net_bps"], 20.0, places=4)

    def test_daily_pipeline(self):
        fr = {"D%d.NS" % i: make_daily(700, seed=i) for i in range(3)}
        r = ml.train_and_validate(fr, "Daily", "up6", "XGBoost", n_folds=3, save=False)
        self.assertGreater(r["bundle"]["summary"]["oos_samples"], 100)


class ScannerTests(unittest.TestCase):
    def test_scan_progress_failures_and_resume(self):
        syms = ["S%d.NS" % i for i in range(25)]
        fr = {s: make_intraday(40, 15, seed=i) for i, s in enumerate(syms)}
        fr["S3.NS"] = fr["S3.NS"].iloc[:20]
        calls = []

        def fetch(ch, tf):
            calls.append(list(ch))
            return {s: fr[s] for s in ch if s != "S5.NS"}
        job = scanner.ScanJob(syms, "15 min", resume=False, fetcher=fetch)
        job.start(); job.thread.join(30)
        p = job.progress()
        self.assertEqual(p["status"], "finished"); self.assertEqual(p["done"], 25)
        self.assertEqual(p["ok"], 23); self.assertEqual(p["failed"], 2)
        self.assertEqual(max(len(c) for c in calls), scanner.BATCH)
        n_calls = len(calls)
        job2 = scanner.ScanJob(syms, "15 min", resume=True, fetcher=fetch)
        job2.start(); job2.thread.join(30)
        self.assertEqual(job2.progress()["resumed"], 25)
        self.assertEqual(len(calls), n_calls)   # nothing downloaded again

    def test_network_failure_is_not_checkpointed_as_symbol_failure(self):
        syms = ["S%d.NS" % i for i in range(5)]
        def boom(ch, tf):
            raise RuntimeError("rate limited")
        job = scanner.ScanJob(syms, "5 min", resume=False, fetcher=boom)
        job.start(); job.thread.join(10)
        self.assertEqual(job.progress()["status"], "failed")
        self.assertEqual(len(job.errors), 0)


class ReportTests(unittest.TestCase):
    def test_reports_and_excel(self):
        syms = ["S%d.NS" % i for i in range(12)]
        rows = [scanner.result_row(analysis.analyze(s, make_intraday(40, 15, seed=i))) for i, s in enumerate(syms)]
        res = pd.DataFrame(rows)
        rep = reports.build_reports(res)
        for k in ("Top Big BUY", "Top Big SELL", "Early Movement", "Reversal", "Breakout", "Breakdown", "High Volume", "Entry-Exit", "SL and Targets"):
            self.assertIn(k, rep)
        raw = reports.to_excel_bytes(rep, {"All results": res})
        import io, openpyxl
        wb = openpyxl.load_workbook(io.BytesIO(raw))
        self.assertIn("All results", wb.sheetnames)
        self.assertGreater(len(reports.to_csv_zip_bytes(rep)), 100)


if __name__ == "__main__":
    unittest.main()
