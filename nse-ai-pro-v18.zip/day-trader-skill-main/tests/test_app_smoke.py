"""Streamlit AppTest smoke test: every page renders with faked Yahoo data (no network)."""
import os
import sys
import tempfile
import time
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
for p in (ROOT, HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

try:
    from streamlit.testing.v1 import AppTest
except Exception:  # pragma: no cover
    AppTest = None

from synth import make_daily, make_intraday  # noqa: E402
from nsepro import data as D, ml, scanner  # noqa: E402

ml.MODEL_DIR = tempfile.mkdtemp()
scanner.CHECKPOINT_DIR = tempfile.mkdtemp()


def fake_download(symbols, interval, period, retries=2):
    out = {}
    for i, s in enumerate(symbols):
        if s.startswith("BAD"):
            continue
        if interval == "1d":
            out[s] = make_daily(520, seed=i + 1)
        else:
            mins = {"5m": 5, "15m": 15, "30m": 30, "60m": 60}[interval]
            days = {"5m": 30, "15m": 40, "30m": 40, "60m": 90}[interval]
            out[s] = make_intraday(days, mins, seed=i + 1, tz=True)
    return out


@unittest.skipIf(AppTest is None, "streamlit testing module unavailable")
class AppSmoke(unittest.TestCase):
    def setUp(self):
        self._orig = D._download_raw
        D._download_raw = fake_download
        D.clear_cache()
        ml.MODEL_DIR = tempfile.mkdtemp()          # isolate from models saved by other tests
        scanner.CHECKPOINT_DIR = tempfile.mkdtemp()

    def tearDown(self):
        D._download_raw = self._orig

    def app(self):
        at = AppTest.from_file(os.path.join(ROOT, "app.py"), default_timeout=120)
        at.run()
        self.assertFalse(at.exception, [e.value for e in at.exception])
        return at

    def go(self, at, page):
        at.sidebar.radio[0].set_value(page).run()
        self.assertFalse(at.exception, [e.value for e in at.exception])

    def test_all_pages_render(self):
        at = self.app()
        for page in ("🚀 Big Movement Scanner", "🔍 AI Stock Search", "🤖 AI Model (ML)", "📋 Reports", "📘 Original project modules", "🧠 18-Agent Smart Money Scanner"):
            self.go(at, page)

    def test_search_page_full_report(self):
        at = self.app()
        self.go(at, "🔍 AI Stock Search")
        at.text_input(key="search_symbol").set_value("tcs")
        [b for b in at.button if "ANALYZE" in b.label][0].click().run()
        self.assertFalse(at.exception, [e.value for e in at.exception])
        heads = " ".join(h.value for h in at.header) + " ".join(s.value for s in at.subheader)
        for must in ("TCS", "Trend by timeframe", "Indicators and levels", "Reversal prediction", "Entry, exit and risk", "Chart", "ML model probabilities"):
            self.assertIn(must, heads)
        self.assertTrue(any("No trained model" in i.value for i in at.info))   # no invented probabilities

    def test_search_bad_symbol_is_handled(self):
        at = self.app()
        self.go(at, "🔍 AI Stock Search")
        at.text_input(key="search_symbol").set_value("BADSYM")
        [b for b in at.button if "ANALYZE" in b.label][0].click().run()
        self.assertFalse(at.exception)
        self.assertTrue(any("No usable" in e.value for e in at.error))

    def test_scan_then_reports_and_ml(self):
        at = self.app()
        self.go(at, "🚀 Big Movement Scanner")
        at.selectbox(key="bm_preset").set_value("Custom list").run()
        at.text_area(key="bm_text_Custom list").set_value("RELIANCE, TCS, INFY, HDFCBANK, BADONE, SBIN").run()
        [b for b in at.button if "START SCAN" in b.label][0].click().run()
        job = at.session_state["bm_job"]
        job.thread.join(60)
        at.run()
        self.assertFalse(at.exception, [e.value for e in at.exception])
        res = at.session_state["bm_results"]
        self.assertEqual(len(res), 5)
        self.assertEqual(len(at.session_state["bm_failures"]), 1)
        self.go(at, "📋 Reports")
        self.assertTrue(any("Scan:" in s.value for s in at.success))
        self.go(at, "🤖 AI Model (ML)")
        at.multiselect(key="ml_targets").set_value(["up3"]).run()
        [b for b in at.button if "TRAIN" in b.label][0].click().run()
        self.assertFalse(at.exception, [e.value for e in at.exception])
        out = at.session_state["ml_results"]
        self.assertIn("up3", out["results"])
        self.assertNotIn("error", out["results"]["up3"], out["results"]["up3"].get("error"))


if __name__ == "__main__":
    unittest.main()
