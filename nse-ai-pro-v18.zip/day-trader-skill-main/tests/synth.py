"""Deterministic synthetic OHLCV for offline tests. This is test scaffolding only: the app never uses it."""
import numpy as np
import pandas as pd

IST = "Asia/Kolkata"


def make_intraday(days=40, bar_min=15, seed=1, start_price=1000.0, drift=0.0, vol=0.0016, tz=True):
    rng = np.random.default_rng(seed)
    days_idx = pd.bdate_range("2026-08-03", periods=days)
    rows, idx, p = [], [], start_price
    nb = int(375 / bar_min)
    for di, day in enumerate(days_idx):
        regime = 1 + 2.5 * (rng.random() < 0.08)  # occasional high-vol sessions
        for b in range(nb):
            ts = day + pd.Timedelta(minutes=9 * 60 + 15 + b * bar_min)
            tod = 1.8 if b in (0, 1, nb - 1) else 1.0
            r = drift + rng.normal(0, vol * regime * np.sqrt(bar_min / 15) * tod)
            o = p
            c = o * (1 + r)
            hi = max(o, c) * (1 + abs(rng.normal(0, vol * 0.5)))
            lo = min(o, c) * (1 - abs(rng.normal(0, vol * 0.5)))
            v = float(rng.lognormal(10.5, 0.45) * tod * (1 + 8 * abs(r) / vol / 10))
            rows.append((o, hi, lo, c, v)); idx.append(ts); p = c
    df = pd.DataFrame(rows, columns=["Open", "High", "Low", "Close", "Volume"], index=pd.DatetimeIndex(idx))
    return df.tz_localize(IST) if tz else df


def make_daily(days=600, seed=2, start_price=500.0, drift=0.0004, vol=0.013):
    rng = np.random.default_rng(seed)
    idx = pd.bdate_range("2024-01-01", periods=days)
    r = rng.normal(drift, vol, days)
    c = start_price * np.exp(np.cumsum(r))
    o = np.r_[start_price, c[:-1]] * (1 + rng.normal(0, 0.003, days))
    hi = np.maximum(o, c) * (1 + np.abs(rng.normal(0, 0.005, days)))
    lo = np.minimum(o, c) * (1 - np.abs(rng.normal(0, 0.005, days)))
    v = rng.lognormal(13, 0.4, days) * (1 + 20 * np.abs(r))
    return pd.DataFrame({"Open": o, "High": hi, "Low": lo, "Close": c, "Volume": v}, index=idx)
