"""Big Movement scanner page."""
from __future__ import annotations

import time

import pandas as pd
import streamlit as st

from . import data as D
from .reports import build_reports, to_csv_zip_bytes, to_excel_bytes
from .scanner import ScanJob
from .ui_common import DISCLAIMER, goto, show_df, universe_picker

SEARCH_PAGE = "🔍 AI Stock Search"


@st.fragment(run_every=2)
def _progress_panel():
    job: ScanJob | None = st.session_state.get("bm_job")
    if job is None:
        return
    p = job.progress()
    st.progress(p["fraction"], text="%s: %d/%d analysed (%d ok, %d skipped)%s" % (
        p["status"].upper(), p["done"], p["total"], p["ok"], p["failed"],
        ", %d restored from checkpoint" % p["resumed"] if p["resumed"] else ""))
    if p["message"]:
        (st.error if p["status"] == "failed" else st.caption)(p["message"])
    if p["status"] in ("finished", "stopped", "failed") and not st.session_state.get("bm_published") == id(job):
        st.session_state["bm_results"] = job.results()
        st.session_state["bm_failures"] = job.failures()
        st.session_state["bm_meta"] = {"tf": job.tf, "time": time.strftime("%Y-%m-%d %H:%M:%S"), "n": p["ok"]}
        st.session_state["bm_published"] = id(job)
        st.rerun(scope="app")


def render_page():
    st.title("🚀 Big Movement Scanner (NSE)")
    st.caption("Early and strong BUY/SELL setups, volume explosions, breakouts, liquidity sweeps and reversals. Yahoo Finance data, completed candles only.")
    st.warning(DISCLAIMER)
    c1, c2 = st.columns(2)
    with c1:
        tf = st.selectbox("Timeframe", list(D.TIMEFRAMES), index=1, key="bm_tf")
    with c2:
        resume = st.checkbox("Resume from checkpoint if available", value=True, key="bm_resume")
    syms = universe_picker("bm")
    b1, b2, b3 = st.columns([1, 1, 1])
    job: ScanJob | None = st.session_state.get("bm_job")
    running = job is not None and job.thread is not None and job.thread.is_alive()
    if b1.button("🔎 START SCAN", type="primary", disabled=running, width="stretch"):
        job = ScanJob(syms, tf, resume=resume)
        st.session_state["bm_job"] = job
        st.session_state.pop("bm_published", None)
        job.start()
        st.rerun()
    if b2.button("⏹ Stop (keeps progress)", disabled=not running, width="stretch") and job:
        job.stop()
    if b3.button("🧹 Clear Yahoo cache", width="stretch"):
        D.clear_cache()
        st.toast("Cache cleared")
    st.caption("Cache: %s" % D.cache_stats())
    _progress_panel()

    res: pd.DataFrame = st.session_state.get("bm_results")
    if res is None or res.empty:
        st.info("Choose a universe and press START SCAN. The scan runs in the background; the page stays responsive.")
        return
    meta = st.session_state.get("bm_meta", {})
    st.success("Results: %d symbols analysed on %s (finished %s)." % (len(res), meta.get("tf", "?"), meta.get("time", "?")))
    f1, f2, f3 = st.columns(3)
    min_conf = f1.slider("Minimum validated confidence", 0, 100, 0, 5, key="bm_minconf")
    side = f2.selectbox("Side", ["All", "BUY", "SELL"], key="bm_side")
    only_valid = f3.checkbox("Only valid trade plans", value=False, key="bm_valid")
    view = res[res["Confidence (validated)"] >= min_conf]
    if side != "All":
        view = view[view["Side"] == side]
    if only_valid:
        view = view[view["Plan valid"]]
    reports = build_reports(view)
    pred = st.session_state.get("ml_predictions")
    if pred is not None and len(pred):
        reports = build_reports(view, pred)
    tabs = st.tabs(["All", "Big BUY", "Big SELL", "Early", "Reversal", "Breakout", "Breakdown", "High volume", "Entry/Exit"])
    keymap = [None, "Top Big BUY", "Top Big SELL", "Early Movement", "Reversal", "Breakout", "Breakdown", "High Volume", "Entry-Exit"]
    for tab, k in zip(tabs, keymap):
        with tab:
            tbl = view.sort_values("Confidence (validated)", ascending=False) if k is None else reports.get(k, pd.DataFrame())
            if k is None:
                tbl = tbl[[c for c in tbl.columns if c != "Yahoo"]]
            if len(tbl):
                show_df(tbl)
            else:
                st.caption("No symbols match this report right now.")
    sel = st.selectbox("Open a symbol in AI Stock Search", [""] + list(view["Symbol"]), key="bm_open")
    if sel:
        st.button("Open %s analysis" % sel, on_click=goto, args=(SEARCH_PAGE,), kwargs={"search_symbol": sel, "search_autorun": True})
    d1, d2 = st.columns(2)
    d1.download_button("⬇ Excel (all reports)", to_excel_bytes(reports, {"All results": view}), "nse_big_move_reports.xlsx",
                       "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", width="stretch")
    d2.download_button("⬇ CSV (zip of reports)", to_csv_zip_bytes({**reports, "All results": view}), "nse_big_move_reports_csv.zip", "application/zip", width="stretch")
    fails = st.session_state.get("bm_failures")
    if fails is not None and len(fails):
        with st.expander("Skipped / failed symbols (%d)" % len(fails)):
            show_df(fails)
    with st.expander("How the confidence score works (read this)"):
        st.markdown("""
**Rule score (0-100)** is a weighted confluence of independent conditions on the last completed candle: trend alignment (15), MACD/RSI momentum (15),
acceleration (10), relative volume (15 + 5 bonus for 2.5x+), breakout or break of structure (15), VWAP side (10), candle strength (10), volatility squeeze release (5).
It is **not** a probability.

**Validated confidence** = rule score x a validation factor. The factor comes from testing the *same kind of signal* on this symbol's own fetched history:
did price reach +1.5 ATR before -1.0 ATR within the horizon? Factor 1.0 needs 20+ past signals and a hit rate at least 5 points above the baseline of all bars;
0.8 means no clear edge; 0.6 means unvalidated (too few past signals) or underperforming. The past hit rate, baseline and sample count are shown in the table.

**Signals:** *Early Big BUY/SELL* = volatility compression + building volume + price coiled at the breakout level (or a sweep with volume), before the move.
*Strong Momentum* = score 70+ with ADX 18+ and RVOL 1.5+. *Institutional-style volume* is an estimate from heavy volume and efficient candles, not real order data.
""")
