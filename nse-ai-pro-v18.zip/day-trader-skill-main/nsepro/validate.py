"""Signal validation by barrier outcomes on the symbol's own history.

For every bar t: entering at close[t], did price reach +target_atr * ATR (win) before -stop_atr * ATR (loss)
within `horizon` bars of the same session? Anything else is a timeout (not a win). Used for:
  * hit rate of a signal vs the hit rate of ALL bars (baseline), with a Wilson lower bound
  * the validation factor that turns a rule score into a validated confidence
"""
from __future__ import annotations

import math

import numpy as np
import pandas as pd


def barrier_outcomes(df: pd.DataFrame, side: str, horizon: int = 6, target_atr: float = 1.5,
                     stop_atr: float = 1.0, same_session: bool = True) -> pd.Series:
    """+1 win, -1 loss, 0 timeout, NaN when fewer than `horizon` future bars exist. Uses future bars on purpose
    (it measures what happened AFTER a signal); it must never be used as a model feature."""
    n = len(df)
    c = df["Close"].to_numpy(float)
    h, l, a = df["High"].to_numpy(float), df["Low"].to_numpy(float), df["atr"].to_numpy(float)
    day = np.asarray(df.index.normalize().asi8) if same_session else np.zeros(n, np.int64)
    res = np.zeros(n)
    done = np.zeros(n, bool)
    sgn = 1.0 if side == "BUY" else -1.0
    tgt, stp = c + sgn * target_atr * a, c - sgn * stop_atr * a
    for j in range(1, horizon + 1):
        idx = np.arange(n)
        ok = idx + j < n
        fj = np.where(ok, idx + j, n - 1)
        valid = ok & (day[fj] == day) & ~done
        hh, ll = h[fj], l[fj]
        if side == "BUY":
            win, loss = hh >= tgt, ll <= stp
        else:
            win, loss = ll <= tgt, hh >= stp
        both = win & loss  # same bar touched both: be conservative, count as a loss
        res = np.where(valid & loss, -1.0, np.where(valid & win & ~both, 1.0, res))
        done |= valid & (win | loss)
    out = pd.Series(res, index=df.index)
    out.iloc[max(0, n - horizon):] = np.nan
    return out


def wilson_lower(wins: int, n: int, z: float = 1.64) -> float:
    if n == 0:
        return 0.0
    p = wins / n
    den = 1 + z * z / n
    centre = p + z * z / (2 * n)
    margin = z * math.sqrt((p * (1 - p) + z * z / (4 * n)) / n)
    return max(0.0, (centre - margin) / den)


def validate_signal(df: pd.DataFrame, mask: pd.Series, side: str, horizon: int = 6, min_n: int = 20) -> dict:
    """Hit rate of `mask` bars vs baseline of all bars, ignoring the final `horizon` bars (outcome unknown)."""
    oc = barrier_outcomes(df, side, horizon)
    known = oc.notna()
    base_n = int(known.sum())
    base_wins = int((oc[known] == 1).sum())
    sig = mask.fillna(False) & known
    n = int(sig.sum())
    wins = int((oc[sig] == 1).sum())
    base = base_wins / base_n if base_n else 0.0
    rate = wins / n if n else 0.0
    lb = wilson_lower(wins, n)
    edge = rate - base
    if n < min_n:
        factor, status = 0.6, "unvalidated (fewer than %d past signals)" % min_n
    elif lb >= base + 0.0 and edge >= 0.05:
        factor, status = 1.0, "validated edge on this symbol's history"
    elif edge <= -0.05:
        factor, status = 0.6, "signal underperformed baseline on this symbol"
    else:
        factor, status = 0.8, "no clear edge over baseline"
    return {"n": n, "wins": wins, "hit_rate": rate, "baseline": base, "edge": edge, "wilson_lb": lb,
            "factor": factor, "status": status}


def validated_confidence(score: float, validation: dict) -> float:
    return round(float(score) * validation["factor"], 1)
