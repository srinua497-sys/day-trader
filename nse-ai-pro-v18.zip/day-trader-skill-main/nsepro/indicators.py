"""Causal technical indicators (each value uses only data up to and including that bar)."""
from __future__ import annotations

import numpy as np
import pandas as pd

from .data import is_intraday


def ema(s: pd.Series, n: int) -> pd.Series:
    return s.ewm(span=n, adjust=False).mean()


def rsi(c: pd.Series, n: int = 14) -> pd.Series:
    d = c.diff()
    up = d.clip(lower=0).ewm(alpha=1 / n, adjust=False).mean()
    dn = (-d.clip(upper=0)).ewm(alpha=1 / n, adjust=False).mean()
    out = 100 - 100 / (1 + up / dn.replace(0, np.nan))
    return out.where(dn != 0, 100.0).fillna(50.0)


def macd(c: pd.Series, fast: int = 12, slow: int = 26, sig: int = 9):
    line = ema(c, fast) - ema(c, slow)
    signal = line.ewm(span=sig, adjust=False).mean()
    return line, signal, line - signal


def true_range(df: pd.DataFrame) -> pd.Series:
    pc = df["Close"].shift()
    return pd.concat([df["High"] - df["Low"], (df["High"] - pc).abs(), (df["Low"] - pc).abs()], axis=1).max(axis=1)


def atr(df: pd.DataFrame, n: int = 14) -> pd.Series:
    return true_range(df).ewm(alpha=1 / n, adjust=False).mean()


def adx(df: pd.DataFrame, n: int = 14):
    a = atr(df, n).replace(0, np.nan)
    up, dn = df["High"].diff(), -df["Low"].diff()
    pdm = pd.Series(np.where((up > dn) & (up > 0), up, 0.0), index=df.index)
    mdm = pd.Series(np.where((dn > up) & (dn > 0), dn, 0.0), index=df.index)
    pdi = 100 * pdm.ewm(alpha=1 / n, adjust=False).mean() / a
    mdi = 100 * mdm.ewm(alpha=1 / n, adjust=False).mean() / a
    dx = 100 * (pdi - mdi).abs() / (pdi + mdi).replace(0, np.nan)
    return dx.ewm(alpha=1 / n, adjust=False).mean().fillna(0.0), pdi.fillna(0.0), mdi.fillna(0.0)


def vwap(df: pd.DataFrame, intraday: bool) -> pd.Series:
    """Session VWAP (resets each trading day) for intraday data; rolling 20-day VWAP for daily data."""
    tp = (df["High"] + df["Low"] + df["Close"]) / 3
    pv = tp * df["Volume"]
    if intraday:
        day = df.index.normalize()
        cum_pv = pv.groupby(day).cumsum()
        cum_v = df["Volume"].groupby(day).cumsum()
    else:
        cum_pv = pv.rolling(20, min_periods=1).sum()
        cum_v = df["Volume"].rolling(20, min_periods=1).sum()
    return (cum_pv / cum_v.replace(0, np.nan)).fillna(df["Close"])


def rvol(df: pd.DataFrame, intraday: bool) -> pd.Series:
    """Relative volume. Intraday: volume vs the average of the same time-of-day over the previous
    sessions (needs 3+). Fallback and daily: volume vs the previous 20 bars. Never uses the current bar in the baseline."""
    v = df["Volume"].astype(float)
    base20 = v.shift(1).rolling(20, min_periods=5).mean()
    if intraday:
        tod = pd.Series(df.index.strftime("%H:%M"), index=df.index)
        tod_base = v.groupby(tod).transform(lambda s: s.shift(1).rolling(10, min_periods=3).mean())
        base = tod_base.where(tod_base > 0, base20)
    else:
        base = base20
    return (v / base.replace(0, np.nan)).replace([np.inf, -np.inf], np.nan).fillna(1.0)


def add_indicators(df: pd.DataFrame, intraday: bool | None = None) -> pd.DataFrame:
    d = df.copy()
    intraday = is_intraday(d) if intraday is None else intraday
    c = d["Close"]
    d["ema9"], d["ema20"], d["ema50"] = ema(c, 9), ema(c, 20), ema(c, 50)
    d["ema200"] = ema(c, 200)
    d["rsi"] = rsi(c)
    d["macd"], d["macd_sig"], d["macd_hist"] = macd(c)
    d["atr"] = atr(d).bfill()
    d["adx"], d["pdi"], d["mdi"] = adx(d)
    d["vwap"] = vwap(d, intraday)
    d["rvol"] = rvol(d, intraday)
    rng = (d["High"] - d["Low"]).replace(0, np.nan)
    d["close_loc"] = ((c - d["Low"]) / rng).fillna(0.5)
    d["body_ratio"] = ((c - d["Open"]).abs() / rng).fillna(0.0)
    d["atr_pct"] = d["atr"] / c * 100
    ratio = d["atr"] / d["atr"].rolling(20, min_periods=5).mean()
    d["atr_ratio"] = ratio.fillna(1.0)
    d["mfm"] = (((c - d["Low"]) - (d["High"] - c)) / rng).fillna(0.0)
    d["est_flow"] = d["mfm"] * d["Volume"]          # estimated directional volume (money flow), not real order flow
    d["value_cr"] = d["Volume"] * c / 1e7            # traded value in Rs crore for the bar
    return d
