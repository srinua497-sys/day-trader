"""Per-symbol analysis: signals, validation, reversal, trade plan, multi-timeframe trend, BUY/SELL/WAIT decision."""
from __future__ import annotations

from typing import Dict, Optional

import numpy as np
import pandas as pd

from .data import is_intraday
from .levels import trade_plan
from .reversal import reversal_frame, reversal_state
from .signals import compute_signals, label_row
from .structure import key_levels, structure_name
from .validate import validate_signal, validated_confidence

MIN_BARS = 60
TREND_WEIGHT = {"5 min": 1.0, "15 min": 1.5, "30 min": 1.5, "1 hour": 2.0, "Daily": 2.0}


def trend_of(d: pd.DataFrame) -> dict:
    """UP / DOWN / SIDEWAYS from EMA stack, price vs EMA20 and swing structure on the last completed bar."""
    r = d.iloc[-1]
    up = int(r["Close"] > r["ema20"]) + int(r["ema20"] > r["ema50"]) + int(r["structure"] > 0) + int(r["macd_hist"] > 0)
    dn = int(r["Close"] < r["ema20"]) + int(r["ema20"] < r["ema50"]) + int(r["structure"] < 0) + int(r["macd_hist"] < 0)
    if up >= 3 and up > dn:
        name, v = "UP", 1
    elif dn >= 3 and dn > up:
        name, v = "DOWN", -1
    else:
        name, v = "SIDEWAYS", 0
    return {"trend": name, "value": v, "ema20": float(r["ema20"]), "ema50": float(r["ema50"]),
            "rsi": float(r["rsi"]), "close": float(r["Close"])}


def analyze(symbol: str, raw: pd.DataFrame, horizon: int = 6) -> dict:
    """Full single-timeframe analysis of the last completed bar. Raises ValueError if too little data."""
    if raw is None or len(raw) < MIN_BARS:
        raise ValueError("%s: need at least %d candles, got %d" % (symbol, MIN_BARS, 0 if raw is None else len(raw)))
    intraday = is_intraday(raw)
    d = compute_signals(raw, intraday)
    last = d.iloc[-1]
    lv = key_levels(d)
    lab = label_row(last)
    rf = reversal_frame(d)
    rev = reversal_state(d, rf)
    plans = {s: trade_plan(d, s, intraday, lv) for s in ("BUY", "SELL")}
    side = lab["side"]
    if side == "NONE":
        side = "BUY" if last["buy_score"] >= last["sell_score"] else "SELL"
    score = float(last["buy_score"] if side == "BUY" else last["sell_score"])
    mask = d["strong_buy"] | d["early_buy"] if side == "BUY" else d["strong_sell"] | d["early_sell"]
    val = validate_signal(d, mask, side, horizon=horizon if intraday else 5)
    prev = float(d["Close"].iloc[-2])
    flags = {k: bool(last[k]) for k in ("breakout", "breakdown", "vol_explosion", "vol_surge", "sweep_up", "sweep_down",
                                         "accel_up", "accel_down", "inst_buy", "inst_sell", "squeeze")}
    return {"symbol": symbol, "frame": d, "intraday": intraday, "time": d.index[-1], "price": float(last["Close"]),
            "change_pct": (float(last["Close"]) / prev - 1) * 100 if prev else 0.0,
            "label": lab["label"], "side": side, "buy_score": float(last["buy_score"]), "sell_score": float(last["sell_score"]),
            "score": score, "validation": val, "confidence": validated_confidence(score, val) if lab["side"] != "NONE" else 0.0,
            "rvol": float(last["rvol"]), "rsi": float(last["rsi"]), "atr": float(last["atr"]), "atr_pct": float(last["atr_pct"]),
            "adx": float(last["adx"]), "vwap": float(last["vwap"]), "ema20": float(last["ema20"]), "ema50": float(last["ema50"]),
            "ema200": float(last["ema200"]), "macd_hist": float(last["macd_hist"]), "structure": structure_name(last["structure"]),
            "breakout_level": float(last["brk_high"]), "breakdown_level": float(last["brk_low"]), "levels": lv,
            "flags": flags, "reversal": rev, "plans": plans, "est_value_cr": float(last["value_cr"]),
            "est_flow": float(last["est_flow"]), "trend": trend_of(d)}


def decide(per_tf: Dict[str, dict], main_tf: str) -> dict:
    """BUY / SELL / WAIT using the main timeframe's signal and the weighted multi-timeframe trend vote."""
    votes = {tf: a["trend"]["value"] for tf, a in per_tf.items()}
    wsum = sum(TREND_WEIGHT.get(tf, 1.0) * v for tf, v in votes.items())
    wmax = sum(TREND_WEIGHT.get(tf, 1.0) for tf in votes) or 1.0
    m = per_tf[main_tf]
    side = m["side"]
    plan = m["plans"][side]
    reasons = []
    aligned = (wsum / wmax) * (1 if side == "BUY" else -1)
    decision = "WAIT"
    strong = m["label"] in ("Strong Momentum BUY", "Strong Momentum SELL", "Early Big BUY", "Early Big SELL")
    if strong and aligned >= 0.25 and plan["valid"]:
        decision = side
        reasons.append("%s signal on %s with %.0f%% multi-timeframe alignment" % (m["label"], main_tf, aligned * 100))
    else:
        if not strong:
            reasons.append("No strong or early signal on %s (score %.0f)" % (main_tf, m["score"]))
        if aligned < 0.25:
            reasons.append("Higher timeframes do not support a %s (alignment %.0f%%)" % (side, aligned * 100))
        if not plan["valid"]:
            reasons.append("Trade plan invalid: " + plan["invalid_reason"])
    rev = m["reversal"]["state"]
    if rev in ("REVERSAL UP", "REVERSAL DOWN") and decision != "WAIT":
        against = (rev == "REVERSAL DOWN" and decision == "BUY") or (rev == "REVERSAL UP" and decision == "SELL")
        if against:
            decision = "WAIT"
            reasons.append("%s state conflicts with the signal" % rev)
    if decision == "WAIT" and rev in ("REVERSAL UP", "REVERSAL DOWN") and m["reversal"]["conditions_met"] >= 4:
        reasons.append("%s forming; wait for the confirmation close" % rev)
    return {"decision": decision, "side_considered": side, "alignment": aligned, "reasons": reasons, "plan": plan}
