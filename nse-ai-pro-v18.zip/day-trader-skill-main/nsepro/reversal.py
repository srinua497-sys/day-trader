"""Reversal detection: 8 independent conditions per side, evaluated on completed bars only."""
from __future__ import annotations

import numpy as np
import pandas as pd

from .structure import K, swing_points, sweeps, confirmed_swings

CONDITIONS = ["RSI divergence", "MACD momentum turn", "Volume exhaustion", "Liquidity sweep",
              "Reversal candle", "EMA9/20 cross", "VWAP reclaim/rejection", "S/R rejection"]


def rsi_divergence(df: pd.DataFrame, k: int = K, hold: int = 10):
    """Bullish: price lower low but RSI higher low at the last two confirmed swing lows (bearish mirrors it).
    The flag turns on at the confirmation bar of the second swing and stays on for `hold` bars."""
    sh, sl = swing_points(df, k)
    n = len(df)
    rsi_v = df["rsi"].to_numpy(float)
    bull, bear = np.zeros(n, bool), np.zeros(n, bool)

    def scan(mask, price, rsi_cmp, out):
        idx = np.flatnonzero(mask)
        for a, b in zip(idx[:-1], idx[1:]):
            if b - a < 3 or b - a > 60:
                continue
            if rsi_cmp(price[a], price[b], rsi_v[a], rsi_v[b]):
                s, e = b + k, min(b + k + hold, n)
                if s < n:
                    out[s:e] = True

    scan(sl, df["Low"].to_numpy(float), lambda pa, pb, ra, rb: pb < pa and rb > ra + 1.0, bull)
    scan(sh, df["High"].to_numpy(float), lambda pa, pb, ra, rb: pb > pa and rb < ra - 1.0, bear)
    return pd.Series(bull, index=df.index), pd.Series(bear, index=df.index)


def reversal_frame(df: pd.DataFrame) -> pd.DataFrame:
    """Needs add_indicators() columns. Returns per-bar condition flags and counts for UP and DOWN reversals."""
    c, o, h, l, a = df["Close"], df["Open"], df["High"], df["Low"], df["atr"]
    bull_div, bear_div = rsi_divergence(df)
    sw = sweeps(df)
    rng = (h - l).replace(0, np.nan)
    lower_wick = (np.minimum(o, c) - l) / rng
    upper_wick = (h - np.maximum(o, c)) / rng
    bull_candle = ((lower_wick >= 0.55) & (c >= o)) | ((c > o) & (o <= c.shift()) & (c >= o.shift()) & (c.shift() < o.shift()))
    bear_candle = ((upper_wick >= 0.55) & (c <= o)) | ((c < o) & (o >= c.shift()) & (c <= o.shift()) & (c.shift() > o.shift()))
    hist = df["macd_hist"]
    macd_up = (hist > hist.shift()) & (hist.shift() > hist.shift(2)) & (hist.shift(2) < 0)
    macd_dn = (hist < hist.shift()) & (hist.shift() < hist.shift(2)) & (hist.shift(2) > 0)
    climax = df["rvol"].shift(1).rolling(3).max() >= 2.0
    exhaust = climax & (df["rvol"] < 0.8 * df["rvol"].shift(1).rolling(3).max()) & (rng < a * 0.9)
    e9, e20 = df["ema9"], df["ema20"]
    cross_up = (e9 > e20) & (e9.shift() <= e20.shift())
    cross_dn = (e9 < e20) & (e9.shift() >= e20.shift())
    vw = df["vwap"]
    vw_up = (c > vw) & (c.shift() <= vw.shift())
    vw_dn = (c < vw) & (c.shift() >= vw.shift())
    # support / resistance rejection using confirmed swing points
    s = confirmed_swings(df)
    sup_rej = (l <= s["swing_low"] + 0.25 * a) & (c > s["swing_low"]) & (c > o)
    res_rej = (h >= s["swing_high"] - 0.25 * a) & (c < s["swing_high"]) & (c < o)
    # a reversal only means something after a move: net 10-bar move of at least 1.5 ATR against it
    move10 = (c - c.shift(10)) / a
    prior_down, prior_up = move10 <= -1.5, move10 >= 1.5
    up_cols = pd.DataFrame({CONDITIONS[0]: bull_div, CONDITIONS[1]: macd_up, CONDITIONS[2]: exhaust & (c > o),
                            CONDITIONS[3]: sw["sweep_down"], CONDITIONS[4]: bull_candle, CONDITIONS[5]: cross_up,
                            CONDITIONS[6]: vw_up, CONDITIONS[7]: sup_rej}).fillna(False).astype(bool)
    dn_cols = pd.DataFrame({CONDITIONS[0]: bear_div, CONDITIONS[1]: macd_dn, CONDITIONS[2]: exhaust & (c < o),
                            CONDITIONS[3]: sw["sweep_up"], CONDITIONS[4]: bear_candle, CONDITIONS[5]: cross_dn,
                            CONDITIONS[6]: vw_dn, CONDITIONS[7]: res_rej}).fillna(False).astype(bool)
    out = pd.DataFrame(index=df.index)
    out["rev_up_n"] = up_cols.sum(axis=1).where(prior_down, 0)
    out["rev_dn_n"] = dn_cols.sum(axis=1).where(prior_up, 0)
    out["prior_down"], out["prior_up"] = prior_down.fillna(False), prior_up.fillna(False)
    for col in CONDITIONS:
        out["u_" + col] = up_cols[col]
        out["d_" + col] = dn_cols[col]
    return out


def reversal_state(df: pd.DataFrame, rf: pd.DataFrame, i: int = -1) -> dict:
    """Label the reversal state at bar i (default: last bar) with level, confirmation and invalidation."""
    r = rf.iloc[i]
    row = df.iloc[i]
    a = float(row["atr"])
    up_n, dn_n = int(r["rev_up_n"]), int(r["rev_dn_n"])
    if up_n >= 4 and up_n >= dn_n:
        state, n, side = "REVERSAL UP", up_n, "u_"
    elif dn_n >= 4:
        state, n, side = "REVERSAL DOWN", dn_n, "d_"
    elif max(up_n, dn_n) == 3:
        state, n, side = "REVERSAL WATCH", max(up_n, dn_n), "u_" if up_n >= dn_n else "d_"
    else:
        return {"state": "WAIT", "conditions_met": max(up_n, dn_n), "met": [], "level": np.nan,
                "confirmation": "No reversal pattern after a 1.5 ATR move", "invalidation": np.nan}
    met = [c for c in CONDITIONS if bool(r[side + c])]
    window = df.iloc[max(0, len(df) + i - 4 if i < 0 else i - 3): (len(df) + i + 1 if i < 0 else i + 1)]
    if side == "u_":
        level = float(window["High"].max())
        inval = float(window["Low"].min()) - 0.25 * a
        conf = "Close above %.2f with RVOL >= 1.2 (reversal up confirmed)" % level
    else:
        level = float(window["Low"].min())
        inval = float(window["High"].max()) + 0.25 * a
        conf = "Close below %.2f with RVOL >= 1.2 (reversal down confirmed)" % level
    return {"state": state, "conditions_met": n, "met": met, "level": level, "confirmation": conf, "invalidation": inval}
