"""Yahoo Finance data layer: batch downloads, retry, thread-safe TTL cache, clean OHLCV frames.

Yahoo Finance is an unofficial source. Data can be delayed, incomplete or rate limited, so every
call can return an empty frame and callers must handle that.
"""
from __future__ import annotations

import datetime as dt
import threading
import time
from typing import Dict, Iterable, List, Optional

import numpy as np
import pandas as pd

try:  # yfinance is imported lazily so the analysis code stays importable (and testable) without it
    import yfinance as yf
except Exception:  # pragma: no cover
    yf = None

IST = "Asia/Kolkata"
OPEN_MIN, CLOSE_MIN = 9 * 60 + 15, 15 * 60 + 30
OHLCV = ["Open", "High", "Low", "Close", "Volume"]

# label -> (yahoo interval, yahoo period, bar minutes). Yahoo limits: 5m/15m/30m about 60 days, 60m about 730 days.
TIMEFRAMES = {
    "5 min": ("5m", "30d", 5),
    "15 min": ("15m", "60d", 15),
    "30 min": ("30m", "60d", 30),
    "1 hour": ("60m", "180d", 60),
    "Daily": ("1d", "2y", 1440),
}
TTL_SECONDS = {"5m": 120, "15m": 180, "30m": 300, "60m": 600, "1d": 1800, "1wk": 3600}

_cache: Dict[tuple, tuple] = {}
_lock = threading.Lock()
_stats = {"hits": 0, "downloads": 0}


def cache_stats() -> dict:
    return dict(_stats, entries=len(_cache))


def clear_cache() -> None:
    with _lock:
        _cache.clear()


def now_ist() -> pd.Timestamp:
    return pd.Timestamp.now(tz=IST)


def is_intraday(df: pd.DataFrame) -> bool:
    if df is None or len(df) < 3:
        return False
    d = pd.Series(df.index[-30:]).diff().dropna()
    return bool(len(d) and d.median() < pd.Timedelta(hours=20))


def market_open_now(ts: Optional[pd.Timestamp] = None) -> bool:
    ts = ts or now_ist()
    m = ts.hour * 60 + ts.minute
    return ts.weekday() < 5 and OPEN_MIN <= m < CLOSE_MIN


def clean_frame(df: pd.DataFrame, intraday: bool) -> pd.DataFrame:
    """Normalise one symbol's raw Yahoo frame: flat OHLCV, numeric, sorted, no duplicates, IST index."""
    if df is None or len(df) == 0:
        return pd.DataFrame(columns=OHLCV)
    d = df.copy()
    if isinstance(d.columns, pd.MultiIndex):
        d.columns = d.columns.get_level_values(0)
    d.columns = [str(c).title() for c in d.columns]
    if not all(c in d.columns for c in OHLCV):
        return pd.DataFrame(columns=OHLCV)
    d = d[OHLCV].apply(pd.to_numeric, errors="coerce")
    d = d.dropna(subset=["Open", "High", "Low", "Close"])
    d = d[(d["High"] >= d["Low"]) & (d["Close"] > 0)]
    d["Volume"] = d["Volume"].fillna(0.0)
    d = d[~d.index.duplicated(keep="last")].sort_index()
    if len(d) == 0:
        return d
    idx = pd.DatetimeIndex(d.index)
    if intraday:
        idx = idx.tz_localize(IST) if idx.tz is None else idx.tz_convert(IST)
        d.index = idx
        mins = idx.hour * 60 + idx.minute
        d = d[(mins >= OPEN_MIN) & (mins < CLOSE_MIN)]
    else:
        if idx.tz is not None:
            idx = idx.tz_convert(IST).tz_localize(None)
        d.index = idx.normalize()
        d = d[~d.index.duplicated(keep="last")]
    return d


def drop_forming_bar(df: pd.DataFrame, bar_minutes: int, now: Optional[pd.Timestamp] = None) -> pd.DataFrame:
    """Remove the last candle if it has not closed yet, so signals only use completed bars."""
    if df is None or len(df) == 0:
        return df
    now = now or now_ist()
    last = df.index[-1]
    if bar_minutes >= 1440:  # daily: today's bar is still forming while the market is open
        if market_open_now(now) and pd.Timestamp(last).date() == now.date():
            return df.iloc[:-1]
        return df
    end = last + pd.Timedelta(minutes=bar_minutes)
    session_end = last.normalize() + pd.Timedelta(minutes=CLOSE_MIN)
    end = min(end, session_end)
    return df.iloc[:-1] if now < end else df


def _split_download(raw: pd.DataFrame, symbols: List[str]) -> Dict[str, pd.DataFrame]:
    """Split a yf.download() result into one frame per symbol. Handles both MultiIndex layouts."""
    out: Dict[str, pd.DataFrame] = {}
    if raw is None or len(raw) == 0:
        return out
    if not isinstance(raw.columns, pd.MultiIndex):
        if len(symbols) == 1:
            out[symbols[0]] = raw
        return out
    lv0 = set(map(str, raw.columns.get_level_values(0)))
    lv1 = set(map(str, raw.columns.get_level_values(1)))
    sym_level = 0 if lv0 & set(symbols) else (1 if lv1 & set(symbols) else None)
    if sym_level is None:
        return out
    for s in symbols:
        try:
            sub = raw.xs(s, axis=1, level=sym_level)
        except KeyError:
            continue
        sub = sub.dropna(how="all")
        if len(sub):
            out[s] = sub
    return out


def _download_raw(symbols: List[str], interval: str, period: str, retries: int = 2) -> Dict[str, pd.DataFrame]:
    if yf is None:
        raise RuntimeError("yfinance is not installed")
    got: Dict[str, pd.DataFrame] = {}
    last_err = None
    for attempt in range(retries + 1):
        try:
            raw = yf.download(symbols, interval=interval, period=period, group_by="ticker", auto_adjust=False,
                              actions=False, progress=False, threads=True)
            got = _split_download(raw, symbols)
            if got:
                break
        except Exception as exc:  # network / rate limit
            last_err = exc
        time.sleep(1.0 + attempt)
    missing = [s for s in symbols if s not in got]
    for s in missing[:10]:  # per-symbol fallback, bounded so a bad batch cannot stall the scan
        try:
            h = yf.Ticker(s).history(period=period, interval=interval, auto_adjust=False, actions=False)
            if h is not None and len(h):
                got[s] = h
        except Exception as exc:
            last_err = exc
    if not got and last_err is not None:
        raise RuntimeError("Yahoo Finance request failed: %s" % last_err)
    return got


def get_history_batch(symbols: Iterable[str], tf: str = "15 min", use_cache: bool = True,
                      complete_only: bool = True) -> Dict[str, pd.DataFrame]:
    """Return {symbol: clean OHLCV frame}. Symbols with no data are simply absent. Cached with a TTL."""
    interval, period, bar_min = TIMEFRAMES[tf]
    intraday = interval != "1d"
    ttl = TTL_SECONDS.get(interval, 300)
    result: Dict[str, pd.DataFrame] = {}
    todo: List[str] = []
    now = time.time()
    for s in dict.fromkeys(symbols):
        key = (s, interval, period)
        with _lock:
            hit = _cache.get(key)
        if use_cache and hit and now - hit[0] < ttl:
            _stats["hits"] += 1
            result[s] = hit[1]
        else:
            todo.append(s)
    if todo:
        raw = _download_raw(todo, interval, period)
        _stats["downloads"] += 1
        for s, r in raw.items():
            f = clean_frame(r, intraday)
            with _lock:
                _cache[(s, interval, period)] = (time.time(), f)
            result[s] = f
    out = {}
    for s, f in result.items():
        if len(f) == 0:
            continue
        out[s] = drop_forming_bar(f, bar_min) if complete_only else f
    return {s: f for s, f in out.items() if len(f)}


def get_history(symbol: str, tf: str = "15 min", use_cache: bool = True, complete_only: bool = True) -> pd.DataFrame:
    got = get_history_batch([symbol], tf, use_cache, complete_only)
    return got.get(symbol, pd.DataFrame(columns=OHLCV))
