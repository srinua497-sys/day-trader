"""Trainable ML models on historical Yahoo OHLCV.

Targets (all labelled from FUTURE bars, features only from PAST bars):
  up3        close[t+3] > close[t]
  up6        close[t+6] > close[t]
  bigmove    within the next 6 bars price moves at least 2 ATR away from close[t] (either direction)
  reversal   after a >= 1.5 ATR 10-bar run, price retraces >= 1 ATR against the run within 6 bars (rows without a run are excluded)
Intraday labels never cross the session boundary (rows near the close get no label instead of an overnight gap).
Validation is walk-forward in TIME (pooled across symbols by timestamp) with an embargo gap, so no future row is
ever in a training set. Backtests use out-of-sample predictions only, trade at the NEXT bar's open and pay costs.
"""
from __future__ import annotations

import datetime as dt
import json
import os
from typing import Dict, List, Optional

import joblib
import numpy as np
import pandas as pd

from .data import TIMEFRAMES, is_intraday
from .signals import compute_signals

try:
    from xgboost import XGBClassifier
except Exception:  # pragma: no cover
    XGBClassifier = None
try:
    from lightgbm import LGBMClassifier
except Exception:  # pragma: no cover
    LGBMClassifier = None
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score

MODEL_DIR = os.environ.get("NSEPRO_MODEL_DIR", os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "models"))
WARMUP = 100
TARGETS = {
    "up3": ("Next 3 candles UP/DOWN", 3),
    "up6": ("Next 6 candles UP/DOWN", 6),
    "bigmove": ("Big Movement probability", 6),
    "reversal": ("Reversal probability", 6),
}
FEATURES = ["ret1", "ret3", "ret6", "ret12", "rsi", "rsi_slope", "macd_hist_atr", "ema20_50_atr", "c_ema20_atr", "c_vwap_atr",
            "adx", "di_diff", "rvol_log", "atr_pct", "atr_ratio", "range_atr", "close_loc", "body_atr", "dist_hi20", "dist_lo20",
            "structure", "sweep_up", "sweep_down", "breakout", "breakdown", "accel_up", "accel_down", "squeeze", "buy_score",
            "sell_score", "rev_up_n", "rev_dn_n", "tod", "dow", "run10"]


def available_models() -> List[str]:
    out = []
    if XGBClassifier is not None:
        out.append("XGBoost")
    out.append("Random Forest")
    if LGBMClassifier is not None:
        out.append("LightGBM")
    return out


def make_model(name: str, seed: int = 7):
    if name == "XGBoost" and XGBClassifier is not None:
        return XGBClassifier(n_estimators=250, max_depth=3, learning_rate=0.05, subsample=0.8, colsample_bytree=0.8,
                             min_child_weight=5, reg_lambda=2.0, eval_metric="logloss", n_jobs=2, random_state=seed,
                             tree_method="hist")
    if name == "LightGBM" and LGBMClassifier is not None:
        return LGBMClassifier(n_estimators=250, num_leaves=8, learning_rate=0.05, subsample=0.8, subsample_freq=1,
                              colsample_bytree=0.8, min_child_samples=30, verbose=-1, n_jobs=2, random_state=seed)
    if name == "Random Forest":
        return RandomForestClassifier(n_estimators=250, max_depth=6, min_samples_leaf=20, n_jobs=2, random_state=seed)
    raise ValueError("Model %s is not available in this environment" % name)


def build_features(raw: pd.DataFrame) -> pd.DataFrame:
    """Feature + label frame for one symbol. Last rows have NaN labels (future unknown) but valid features."""
    intraday = is_intraday(raw)
    d = compute_signals(raw, intraday)
    c, a, o = d["Close"], d["atr"], d["Open"]
    X = pd.DataFrame(index=d.index)
    for n in (1, 3, 6, 12):
        X["ret%d" % n] = (c - c.shift(n)) / a
    X["run10"] = (c - c.shift(10)) / a
    X["rsi"], X["rsi_slope"] = d["rsi"], d["rsi"].diff(3)
    X["macd_hist_atr"] = d["macd_hist"] / a
    X["ema20_50_atr"] = (d["ema20"] - d["ema50"]) / a
    X["c_ema20_atr"] = (c - d["ema20"]) / a
    X["c_vwap_atr"] = (c - d["vwap"]) / a
    X["adx"], X["di_diff"] = d["adx"], d["pdi"] - d["mdi"]
    X["rvol_log"] = np.log1p(d["rvol"])
    X["atr_pct"], X["atr_ratio"] = d["atr_pct"], d["atr_ratio"]
    X["range_atr"] = (d["High"] - d["Low"]) / a
    X["close_loc"] = d["close_loc"]
    X["body_atr"] = (c - o) / a
    X["dist_hi20"] = ((d["brk_high"] - c) / a).clip(-10, 10)
    X["dist_lo20"] = ((c - d["brk_low"]) / a).clip(-10, 10)
    X["structure"] = d["structure"]
    for k in ("sweep_up", "sweep_down", "breakout", "breakdown", "accel_up", "accel_down", "squeeze"):
        X[k] = d[k].astype(float)
    X["buy_score"], X["sell_score"] = d["buy_score"], d["sell_score"]
    X["rev_up_n"], X["rev_dn_n"] = d["rev_up_n"], d["rev_dn_n"]
    if intraday:
        X["tod"] = (d.index.hour * 60 + d.index.minute - (9 * 60 + 15)).astype(float)
    else:
        X["tod"] = 0.0
    X["dow"] = d.index.dayofweek.astype(float)
    X = X.replace([np.inf, -np.inf], np.nan).clip(-1e6, 1e6)

    n = len(d)
    day = np.asarray(d.index.normalize().asi8) if intraday else np.zeros(n, np.int64)
    cv, hv, lv = c.to_numpy(float), d["High"].to_numpy(float), d["Low"].to_numpy(float)
    av, ov = a.to_numpy(float), o.to_numpy(float)

    def shifted(arr, h):
        out = np.full(n, np.nan)
        if h < n:
            out[:n - h] = arr[h:]
        return out

    def same_day(h):
        out = np.zeros(n, bool)
        if h < n:
            out[:n - h] = day[h:] == day[:n - h]
        return out

    lab = pd.DataFrame(index=d.index)
    for h, name in ((3, "up3"), (6, "up6")):
        f = shifted(cv, h)
        ok = same_day(h) & np.isfinite(f)
        lab[name] = np.where(ok, (f > cv).astype(float), np.nan)
        lab["exit%d" % h] = np.where(ok, f, np.nan)
    # big move within 6 bars
    ok6 = same_day(6)
    moves = np.vstack([np.abs(shifted(cv, j) - cv) for j in range(1, 7)])
    mx = np.where(np.isnan(moves).any(axis=0), np.nan, moves.max(axis=0))
    lab["bigmove"] = np.where(ok6 & np.isfinite(mx), (mx >= 2 * av).astype(float), np.nan)
    f6 = shifted(cv, 6)
    run = (cv - np.r_[np.full(10, np.nan), cv[:-10]]) / av
    down, up = run <= -1.5, run >= 1.5
    rev = np.where(down & ((f6 - cv) >= av), 1.0, np.where(up & ((cv - f6) >= av), 1.0, 0.0))
    lab["reversal"] = np.where(ok6 & np.isfinite(f6) & (down | up), rev, np.nan)
    nxt_o = shifted(ov, 1)
    lab["entry_px"] = np.where(same_day(1), nxt_o, np.nan)
    out = pd.concat([X, lab], axis=1)
    out["_close"] = cv
    return out.iloc[WARMUP:]


def build_dataset(frames: Dict[str, pd.DataFrame]) -> pd.DataFrame:
    parts = []
    for sym, raw in frames.items():
        if raw is None or len(raw) < WARMUP + 60:
            continue
        f = build_features(raw)
        f["symbol"] = sym
        f["ts"] = f.index
        parts.append(f.reset_index(drop=True))
    if not parts:
        return pd.DataFrame()
    ds = pd.concat(parts, ignore_index=True)
    ti = pd.DatetimeIndex(ds["ts"])
    ds["ts_ns"] = (ti.tz_convert("UTC") if ti.tz is not None else ti).as_unit("ns").asi8
    return ds.sort_values(["ts_ns", "symbol"]).reset_index(drop=True)


def _xy(ds: pd.DataFrame, target: str, model_name: str):
    d = ds[ds[target].notna()]
    X = d[FEATURES]
    if model_name == "Random Forest":
        X = X.fillna(0.0)
    return d, X, d[target].astype(int)


def walk_forward(ds: pd.DataFrame, target: str, model_name: str, tf: str, n_folds: int = 5, min_train_frac: float = 0.5,
                 progress=None) -> dict:
    """Expanding-window walk-forward. Each fold trains on rows strictly older than (test start - embargo)."""
    horizon = TARGETS[target][1]
    bar_min = TIMEFRAMES[tf][2]
    embargo = pd.Timedelta(minutes=horizon * bar_min * (1.6 if bar_min >= 1440 else 1.0))
    d, X, y = _xy(ds, target, model_name)
    if len(d) < 400 or y.nunique() < 2:
        raise ValueError("Not enough labelled samples (%d) to validate; add symbols or use a longer timeframe." % len(d))
    ts = pd.to_datetime(d["ts_ns"], utc=True)
    t0, t1 = ts.min(), ts.max()
    start = t0 + (t1 - t0) * min_train_frac
    edges = [start + (t1 - start) * i / n_folds for i in range(n_folds + 1)]
    folds, oos_parts = [], []
    for k in range(n_folds):
        lo, hi = edges[k], edges[k + 1] + (pd.Timedelta(seconds=1) if k == n_folds - 1 else pd.Timedelta(0))
        tr = ts < (lo - embargo)
        te = (ts >= lo) & (ts < hi)
        if tr.sum() < 200 or te.sum() < 30 or y[tr].nunique() < 2:
            continue
        m = make_model(model_name)
        m.fit(X[tr], y[tr])
        p = m.predict_proba(X[te])[:, 1]
        yt = y[te].to_numpy()
        acc = float(((p >= 0.5).astype(int) == yt).mean())
        maj = int(round(float(y[tr].mean())))
        base = float((yt == maj).mean())
        auc = float(roc_auc_score(yt, p)) if len(np.unique(yt)) == 2 else float("nan")
        folds.append({"fold": k + 1, "train_end": (lo - embargo).strftime("%Y-%m-%d"), "test_start": lo.strftime("%Y-%m-%d"),
                      "test_end": hi.strftime("%Y-%m-%d"), "n_train": int(tr.sum()), "n_test": int(te.sum()),
                      "accuracy": acc, "baseline_accuracy": base, "auc": auc})
        part = d.loc[te, ["symbol", "ts", "ts_ns", "entry_px", "exit3", "exit6", "_close", target]].copy()
        part["p"] = p
        oos_parts.append(part)
        if progress:
            progress((k + 1) / n_folds)
    if not folds:
        raise ValueError("No valid walk-forward fold. Add more symbols or history.")
    oos = pd.concat(oos_parts, ignore_index=True)
    y_all = oos[target].astype(int).to_numpy()
    p_all = oos["p"].to_numpy()
    fr = pd.DataFrame(folds)
    summary = {"oos_samples": int(len(oos)), "oos_accuracy": float(((p_all >= 0.5).astype(int) == y_all).mean()),
               "baseline_accuracy": float(np.average(fr["baseline_accuracy"], weights=fr["n_test"])),
               "oos_auc": float(roc_auc_score(y_all, p_all)) if len(np.unique(y_all)) == 2 else float("nan"),
               "positive_rate": float(y_all.mean()), "folds": int(len(fr)), "labelled_samples": int(len(d))}
    summary["has_edge"] = bool(summary["oos_accuracy"] >= summary["baseline_accuracy"] + 0.01 and summary["oos_auc"] >= 0.52)
    return {"folds": fr, "oos": oos, "summary": summary}


def backtest(oos: pd.DataFrame, target: str, thr: float = 0.55, cost_bps: float = 10.0, allow_short: bool = True) -> dict:
    """Trade OOS signals: long if p >= thr, short if p <= 1-thr (when allowed). Enter at the NEXT bar open,
    exit at close[t+h], pay round-trip cost. One position per symbol at a time. Only for up3 / up6."""
    if target not in ("up3", "up6"):
        raise ValueError("Backtest is defined for the directional targets up3 and up6")
    h = TARGETS[target][1]
    exitc = "exit3" if h == 3 else "exit6"
    trades = []
    for sym, g in oos.sort_values("ts_ns").groupby("symbol"):
        free_at = -1
        for pos, (_, r) in enumerate(g.iterrows()):
            if pos <= free_at or not np.isfinite(r["entry_px"]) or not np.isfinite(r[exitc]):
                continue
            side = 1 if r["p"] >= thr else (-1 if (allow_short and r["p"] <= 1 - thr) else 0)
            if side == 0:
                continue
            gross = side * (r[exitc] / r["entry_px"] - 1.0)
            trades.append({"symbol": sym, "time": r["ts"], "ts_ns": r["ts_ns"], "side": "LONG" if side == 1 else "SHORT",
                           "p_up": r["p"], "gross": gross, "net": gross - cost_bps / 1e4})
            free_at = pos + h
    if not trades:
        return {"trades": pd.DataFrame(), "stats": {"trades": 0}}
    t = pd.DataFrame(trades).sort_values("ts_ns").reset_index(drop=True)
    cum = t["net"].cumsum()
    dd = (cum - cum.cummax()).min()
    wins, losses = t.loc[t["net"] > 0, "net"].sum(), -t.loc[t["net"] < 0, "net"].sum()
    se = t["net"].std(ddof=1) / np.sqrt(len(t)) if len(t) > 1 else np.nan
    stats = {"trades": int(len(t)), "win_rate": float((t["net"] > 0).mean()), "avg_net_bps": float(t["net"].mean() * 1e4),
             "avg_gross_bps": float(t["gross"].mean() * 1e4), "total_net_pct": float(t["net"].sum() * 100),
             "max_drawdown_pct": float(dd * 100), "profit_factor": float(wins / losses) if losses > 0 else float("inf"),
             "t_stat": float(t["net"].mean() / se) if se and np.isfinite(se) and se > 0 else float("nan"),
             "cost_bps": cost_bps, "threshold": thr}
    return {"trades": t, "stats": stats}


def probability_lift(oos: pd.DataFrame, target: str, top_frac: float = 0.1) -> dict:
    """For bigmove / reversal: how often the event happened among the highest-probability OOS rows vs overall."""
    y = oos[target].astype(int)
    k = max(1, int(len(oos) * top_frac))
    top = oos.nlargest(k, "p")
    return {"base_rate": float(y.mean()), "top_decile_rate": float(top[target].mean()), "n_top": int(k),
            "lift": float(top[target].mean() / y.mean()) if y.mean() > 0 else float("nan")}


def train_final(ds: pd.DataFrame, target: str, model_name: str):
    d, X, y = _xy(ds, target, model_name)
    m = make_model(model_name)
    m.fit(X, y)
    return m, int(len(d))


def model_path(tf: str, target: str, model_name: str) -> str:
    safe = lambda s: "".join(ch if ch.isalnum() else "_" for ch in s)
    return os.path.join(MODEL_DIR, "%s__%s__%s.joblib" % (safe(tf), target, safe(model_name)))


def save_bundle(bundle: dict, tf: str, target: str, model_name: str) -> str:
    global MODEL_DIR
    try:
        os.makedirs(MODEL_DIR, exist_ok=True)
        p = model_path(tf, target, model_name)
        joblib.dump(bundle, p)
    except OSError:  # read-only app directory: fall back to the temp dir for this server session
        import tempfile
        MODEL_DIR = os.path.join(tempfile.gettempdir(), "nsepro_models")
        os.makedirs(MODEL_DIR, exist_ok=True)
        p = model_path(tf, target, model_name)
        joblib.dump(bundle, p)
    return p


def load_bundle(tf: str, target: str, model_name: str) -> Optional[dict]:
    p = model_path(tf, target, model_name)
    return joblib.load(p) if os.path.exists(p) else None


def train_and_validate(frames: Dict[str, pd.DataFrame], tf: str, target: str, model_name: str, n_folds: int = 5,
                       cost_bps: float = 10.0, thr: float = 0.55, progress=None, save: bool = True) -> dict:
    ds = build_dataset(frames)
    if ds.empty:
        raise ValueError("No symbol has enough history to train")
    wf = walk_forward(ds, target, model_name, tf, n_folds, progress=progress)
    model, n_fit = train_final(ds, target, model_name)
    bundle = {"model": model, "features": FEATURES, "target": target, "model_name": model_name, "tf": tf,
              "trained_at": dt.datetime.now().isoformat(timespec="seconds"), "n_symbols": len(frames),
              "symbols": sorted(frames), "summary": wf["summary"], "n_fit": n_fit,
              "fit_range": [str(ds["ts"].min()), str(ds["ts"].max())]}
    if target in ("up3", "up6"):
        allow_short = TIMEFRAMES[tf][2] < 1440
        bundle["backtest"] = backtest(wf["oos"], target, thr, cost_bps, allow_short)["stats"]
    else:
        bundle["lift"] = probability_lift(wf["oos"], target)
    if save:
        bundle["path"] = save_bundle(bundle, tf, target, model_name)
    imp = getattr(model, "feature_importances_", None)
    imp_df = pd.DataFrame({"feature": FEATURES, "importance": imp}).sort_values("importance", ascending=False) if imp is not None else pd.DataFrame()
    return {"bundle": bundle, "wf": wf, "dataset_rows": int(len(ds)), "importance": imp_df}


def predict_latest(bundle: dict, frames: Dict[str, pd.DataFrame]) -> pd.DataFrame:
    """Probability for the last completed bar of each symbol using a trained bundle."""
    rows = []
    feats = bundle["features"]
    for sym, raw in frames.items():
        if raw is None or len(raw) < WARMUP + 60:
            continue
        f = build_features(raw)
        x = f[feats].iloc[[-1]]
        if bundle["model_name"] == "Random Forest":
            x = x.fillna(0.0)
        p = float(bundle["model"].predict_proba(x)[:, 1][0])
        rows.append({"Symbol": sym, "Bar time": f.index[-1], "Price": float(f["_close"].iloc[-1]), "p_event": p})
    return pd.DataFrame(rows)
