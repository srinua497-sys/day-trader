"""Readable report tables built from a scan result frame, plus Excel / CSV export."""
from __future__ import annotations

import io
import zipfile
from typing import Dict

import numpy as np
import pandas as pd

BASE = ["Symbol", "Price", "Change %", "Signal", "Confidence (validated)", "Rule score", "RVOL", "RSI"]
PLAN = ["Entry", "Stop loss", "Target 1", "Target 2", "Target 3", "Risk %", "R:R (T2)", "Plan valid", "Plan note"]


def _sel(df, cols):
    return df[[c for c in cols if c in df.columns]]


def build_reports(res: pd.DataFrame, predictions: pd.DataFrame | None = None) -> Dict[str, pd.DataFrame]:
    if res is None or res.empty:
        return {}
    r = res.copy()
    by_conf = lambda x: x.sort_values(["Confidence (validated)", "Rule score"], ascending=False)
    out: Dict[str, pd.DataFrame] = {}
    out["Top Big BUY"] = _sel(by_conf(r[r["Signal"].isin(["Strong Momentum BUY"])]).head(25), BASE + ["Breakout level", "Past hit rate %", "Past signals (n)", "Validation"])
    out["Top Big SELL"] = _sel(by_conf(r[r["Signal"].isin(["Strong Momentum SELL"])]).head(25), BASE + ["Breakdown level", "Past hit rate %", "Past signals (n)", "Validation"])
    out["Early Movement"] = _sel(by_conf(r[r["Signal"].isin(["Early Big BUY", "Early Big SELL"])]), BASE + ["Structure", "Breakout level", "Breakdown level"])
    out["Reversal"] = _sel(r[r["Reversal"].isin(["REVERSAL UP", "REVERSAL DOWN", "REVERSAL WATCH"])].sort_values("Reversal"), BASE + ["Reversal", "Reversal level"])
    out["Breakout"] = _sel(r[r["Breakout"]].sort_values("RVOL", ascending=False), BASE + ["Breakout level"])
    out["Breakdown"] = _sel(r[r["Breakdown"]].sort_values("RVOL", ascending=False), BASE + ["Breakdown level"])
    out["High Volume"] = _sel(r[(r["RVOL"] >= 2.0) | r["Volume explosion"]].sort_values("RVOL", ascending=False), BASE + ["Value (Rs cr)", "Inst. buy est.", "Inst. sell est."])
    sig = r[r["Signal"] != "No signal"]
    out["Entry-Exit"] = _sel(by_conf(sig), ["Symbol", "Signal", "Plan side", "Confidence (validated)"] + PLAN)
    out["SL and Targets"] = _sel(by_conf(sig[sig["Plan valid"]]), ["Symbol", "Plan side", "Entry", "Stop loss", "Target 1", "Target 2", "Target 3", "Risk %"])
    if predictions is not None and len(predictions):
        out["AI Prediction"] = predictions
    return {k: v.reset_index(drop=True) for k, v in out.items()}


def to_excel_bytes(reports: Dict[str, pd.DataFrame], extra: Dict[str, pd.DataFrame] | None = None) -> bytes:
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as xw:
        info = pd.DataFrame({"Note": [
            "NSE AI PRO scan report. Data: Yahoo Finance (unofficial, may be delayed).",
            "Scores are rule confluence, not probabilities. Validated confidence = score x historical validation factor.",
            "Not financial advice. Nothing here places orders."]})
        info.to_excel(xw, sheet_name="About", index=False)
        for name, df in {**reports, **(extra or {})}.items():
            d = df.copy()
            for c in d.columns:  # Excel cannot store tz-aware datetimes
                if str(d[c].dtype).startswith("datetime64") and getattr(d[c].dt, "tz", None) is not None:
                    d[c] = d[c].dt.tz_localize(None)
            d.to_excel(xw, sheet_name=name[:31], index=False)
            ws = xw.sheets[name[:31]]
            for i, col in enumerate(d.columns, 1):
                width = min(max(len(str(col)), *(len(str(x)) for x in d[col].head(200))) + 2 if len(d) else len(str(col)) + 2, 48)
                ws.column_dimensions[ws.cell(row=1, column=i).column_letter].width = width
    return buf.getvalue()


def to_csv_zip_bytes(reports: Dict[str, pd.DataFrame]) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for name, df in reports.items():
            z.writestr(name.replace(" ", "_") + ".csv", df.to_csv(index=False))
    return buf.getvalue()
