"""AI Stock Search page: full analysis report with multi-timeframe trends, levels, plan and interactive chart."""
from __future__ import annotations

import numpy as np
import pandas as pd
import streamlit as st

from . import data as D
from . import ml
from .analysis import MIN_BARS, analyze, decide
from .charts import build_chart
from .ui_common import DISCLAIMER, show_chart, show_df
from .universe import clean_symbol


def _fmt(x, nd=2):
    return "n/a" if x is None or (isinstance(x, float) and not np.isfinite(x)) else ("%.*f" % (nd, x))


def _load_all(symbol: str, complete_only: bool):
    per, errors = {}, {}
    for tf in D.TIMEFRAMES:
        try:
            f = D.get_history(symbol, tf, complete_only=complete_only)
            if len(f) < MIN_BARS:
                errors[tf] = "only %d candles from Yahoo" % len(f)
                continue
            per[tf] = analyze(symbol, f)
        except Exception as exc:
            errors[tf] = str(exc)
    return per, errors


def _ml_panel(symbol: str, tf: str):
    st.subheader("🤖 ML model probabilities")
    shown = False
    for target, (title, _) in ml.TARGETS.items():
        for name in ml.available_models():
            b = ml.load_bundle(tf, target, name)
            if not b:
                continue
            try:
                frames = {symbol: D.get_history(symbol, tf)}
                pr = ml.predict_latest(b, frames)
            except Exception as exc:
                st.caption("%s / %s: could not predict (%s)" % (title, name, exc))
                continue
            if pr.empty:
                continue
            p, s = float(pr["p_event"].iloc[0]), b["summary"]
            shown = True
            with st.container(border=True):
                st.markdown("**%s** · %s · trained %s on %d symbols" % (title, name, b["trained_at"], b["n_symbols"]))
                cols = st.columns(5)
                if target in ("up3", "up6"):
                    cols[0].metric("UP probability", "%.1f%%" % (p * 100))
                    cols[1].metric("DOWN probability", "%.1f%%" % ((1 - p) * 100))
                else:
                    cols[0].metric("Event probability", "%.1f%%" % (p * 100))
                    cols[1].metric("Base rate", "%.1f%%" % (s["positive_rate"] * 100))
                cols[2].metric("Validation accuracy", "%.1f%%" % (s["oos_accuracy"] * 100), "baseline %.1f%%" % (s["baseline_accuracy"] * 100), delta_color="off")
                cols[3].metric("Validation samples", "{:,}".format(s["oos_samples"]))
                cols[4].metric("Training samples", "{:,}".format(b["n_fit"]))
                if not s["has_edge"]:
                    st.warning("This model did not beat its baseline out of sample. Treat the probability as noise, not a signal.")
    if not shown:
        st.info("No trained model for %s yet. Train one in the 🤖 AI Model page. No probability is shown until a model has been trained and validated." % tf)


def render_page():
    st.title("🔍 AI Stock Search & Analysis (NSE)")
    st.caption("Search any valid NSE symbol, for example RELIANCE, TCS, INFY, HDFCBANK. Multi-timeframe analysis from Yahoo Finance.")
    st.warning(DISCLAIMER)
    if "search_symbol" not in st.session_state:
        st.session_state["search_symbol"] = "RELIANCE"
    c1, c2, c3, c4 = st.columns([2, 1.2, 1, 1])
    typed = c1.text_input("NSE symbol", key="search_symbol")
    chart_tf = c2.selectbox("Chart / decision timeframe", list(D.TIMEFRAMES), index=1, key="search_tf")
    complete_only = c3.checkbox("Completed candles only", value=True, key="search_complete")
    go = c4.button("🔎 ANALYZE", type="primary", width="stretch")
    r1, r2 = st.columns([1, 3])
    refresh = r1.button("🔄 Refresh data", width="stretch")
    symbol = clean_symbol(typed)
    auto = st.session_state.pop("search_autorun", False)
    if refresh and symbol:
        for tf, (iv, per_, _) in D.TIMEFRAMES.items():
            D._cache.pop((symbol, iv, per_), None)
        st.session_state["search_done"] = symbol
    if go or auto:
        st.session_state["search_done"] = symbol
    target = st.session_state.get("search_done")
    if not target:
        st.info("Type a symbol and press ANALYZE.")
        return
    if not target:
        return
    with st.spinner("Fetching %s from Yahoo Finance..." % target):
        try:
            per, errors = _load_all(target, complete_only)
        except Exception as exc:
            st.error("Could not fetch data: %s" % exc)
            return
    if chart_tf not in per:
        st.error("No usable %s data for %s (%s). Check the symbol (NSE tickers look like RELIANCE or TCS) or try again later; Yahoo may be rate limiting." % (
            chart_tf, target, errors.get(chart_tf, "empty response")))
        if per:
            st.info("Other timeframes did load: %s. Pick one of them as the chart timeframe." % ", ".join(per))
        return
    main = per[chart_tf]
    dec = decide(per, chart_tf)
    d = main["frame"]
    icon = {"BUY": "🟢", "SELL": "🔴", "WAIT": "🟡"}[dec["decision"]]
    st.header("%s %s  ·  ₹%s  (%+.2f%%)" % (target.replace(".NS", ""), icon + " " + dec["decision"], _fmt(main["price"]), main["change_pct"]))
    st.caption("Last completed %s candle: %s IST. Decision is for %s with multi-timeframe confirmation." % (chart_tf, str(main["time"])[:16], chart_tf))
    for r in dec["reasons"]:
        st.write("• " + r)
    k = st.columns(6)
    k[0].metric("Signal", main["label"])
    k[1].metric("Rule score", "%.0f/100" % main["score"])
    k[2].metric("Validated confidence", "%.0f" % main["confidence"])
    k[3].metric("RVOL", "%.2fx" % main["rvol"])
    k[4].metric("RSI(14)", "%.1f" % main["rsi"])
    k[5].metric("ATR", "%s (%.2f%%)" % (_fmt(main["atr"]), main["atr_pct"]))
    v = main["validation"]
    st.caption("Validation on this symbol's history: %d past signals, hit rate %.0f%% vs baseline %.0f%%. %s." % (v["n"], v["hit_rate"] * 100, v["baseline"] * 100, v["status"]))

    st.subheader("Trend by timeframe")
    rows = []
    for tf in D.TIMEFRAMES:
        if tf in per:
            t = per[tf]["trend"]
            rows.append({"Timeframe": tf, "Trend": t["trend"], "Close": round(t["close"], 2), "EMA20": round(t["ema20"], 2), "EMA50": round(t["ema50"], 2),
                         "RSI": round(t["rsi"], 1), "Signal": per[tf]["label"], "Structure": per[tf]["structure"]})
        else:
            rows.append({"Timeframe": tf, "Trend": "no data", "Signal": errors.get(tf, "")})
    show_df(pd.DataFrame(rows))

    st.subheader("Indicators and levels (%s)" % chart_tf)
    l = main["levels"]
    ind = pd.DataFrame([
        ("RSI(14)", _fmt(main["rsi"], 1)), ("MACD histogram", _fmt(main["macd_hist"], 3)), ("EMA 20 / 50 / 200", "%s / %s / %s" % (_fmt(main["ema20"]), _fmt(main["ema50"]), _fmt(main["ema200"]))),
        ("VWAP", _fmt(main["vwap"])), ("ATR(14)", _fmt(main["atr"])), ("ADX", _fmt(main["adx"], 1)), ("Last bar volume / RVOL", "%s / %.2fx" % ("{:,.0f}".format(d["Volume"].iloc[-1]), main["rvol"])),
        ("Market structure", main["structure"]), ("Support", ", ".join(_fmt(x) for x in l["support"][:3]) or "none found"),
        ("Resistance", ", ".join(_fmt(x) for x in l["resistance"][:3]) or "none found"), ("Breakout level (20-bar high)", _fmt(main["breakout_level"])),
        ("Breakdown level (20-bar low)", _fmt(main["breakdown_level"])), ("Liquidity BUY zones (equal lows)", ", ".join(_fmt(x) for x in l["liq_buy"]) or "none"),
        ("Liquidity SELL zones (equal highs)", ", ".join(_fmt(x) for x in l["liq_sell"]) or "none"),
        ("Liquidity sweep (last bar)", "UP" if main["flags"]["sweep_up"] else "DOWN" if main["flags"]["sweep_down"] else "none"),
        ("Volume explosion / breakout / breakdown", "%s / %s / %s" % (main["flags"]["vol_explosion"], main["flags"]["breakout"], main["flags"]["breakdown"])),
        ("Est. institutional-style volume", "BUY" if main["flags"]["inst_buy"] else "SELL" if main["flags"]["inst_sell"] else "none (estimate from volume + candle shape)"),
    ], columns=["Item", "Value"])
    show_df(ind)

    st.subheader("Reversal prediction")
    rv = main["reversal"]
    badge = {"REVERSAL UP": "🟢", "REVERSAL DOWN": "🔴", "REVERSAL WATCH": "🟠", "WAIT": "⚪"}[rv["state"]]
    st.markdown("### %s %s  (%d of 8 conditions)" % (badge, rv["state"], rv["conditions_met"]))
    if rv["state"] != "WAIT":
        st.write("**Conditions met:** " + ", ".join(rv["met"]))
        st.write("**Reversal level:** %s  ·  **Confirmation:** %s  ·  **Invalidation:** %s" % (_fmt(rv["level"]), rv["confirmation"], _fmt(rv["invalidation"])))
    else:
        st.write(rv["confirmation"])

    st.subheader("Entry, exit and risk")
    pc = st.columns(2)
    for col, side in zip(pc, ("BUY", "SELL")):
        p = main["plans"][side]
        with col.container(border=True):
            st.markdown("**%s plan** %s" % (side, "✅ valid" if p["valid"] else "⛔ invalidated"))
            if not p["valid"]:
                st.caption(p["invalid_reason"])
            show_df(pd.DataFrame([("Entry", _fmt(p["entry"])), ("Stop loss", _fmt(p["stop"])), ("Target 1 (1R)", _fmt(p["t1"])), ("Target 2 (2R)", _fmt(p["t2"])),
                                  ("Target 3 (3R)", _fmt(p["t3"])), ("Risk per share", "%s (%.2f%%)" % (_fmt(p["risk"]), p["risk_pct"])),
                                  ("Reward/Risk to T1 / T2 / T3", "1.0 / 2.0 / 3.0"), ("Initial trailing stop", _fmt(p["trail_initial"])), ("Trailing stop now (chandelier 2 ATR)", _fmt(p["trail_now"]))],
                                 columns=["Level", "Value"]))
            st.caption("Entry: " + p["entry_confirmation"])
            st.caption("Exit: " + p["exit_confirmation"])
            st.caption(p["breakeven_rule"])

    st.subheader("Chart")
    o1, o2, o3, o4 = st.columns(4)
    bars = o1.slider("Candles", 60, 400, 160, 20, key="chart_bars")
    show = {"ema": o2.checkbox("EMAs", True, key="ch_ema"), "vwap": o2.checkbox("VWAP", True, key="ch_vwap"),
            "sr": o3.checkbox("Support / resistance / liquidity", True, key="ch_sr"), "levels": o3.checkbox("Entry, SL, targets", True, key="ch_lv"),
            "markers": o4.checkbox("Breakout / sweep / reversal markers", True, key="ch_mk"), "signals": o4.checkbox("Historical BUY/SELL signals", True, key="ch_sg"),
            "structure": o4.checkbox("HH / HL / LH / LL labels", False, key="ch_st")}
    show_chart(build_chart(d, main, bars, show))
    _ml_panel(target, chart_tf)
