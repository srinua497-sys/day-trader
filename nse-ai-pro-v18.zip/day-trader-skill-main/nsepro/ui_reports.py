"""Reports page: readable tables from the latest scan, with Excel and CSV downloads."""
from __future__ import annotations

import streamlit as st

from .reports import build_reports, to_csv_zip_bytes, to_excel_bytes
from .ui_common import DISCLAIMER, show_df

DESCRIPTIONS = {
    "Top Big BUY": "Strong momentum BUY setups ranked by validated confidence.",
    "Top Big SELL": "Strong momentum SELL setups ranked by validated confidence.",
    "Early Movement": "Early Big BUY/SELL: compression, rising volume, price at the level, before the move.",
    "Reversal": "Reversal UP / DOWN / WATCH states with the reversal level.",
    "Breakout": "Closed above the prior 20-bar high with RVOL of 1.2x or more.",
    "Breakdown": "Closed below the prior 20-bar low with RVOL of 1.2x or more.",
    "High Volume": "RVOL 2x or more, with estimated institutional-style volume flags.",
    "AI Prediction": "ML probabilities from your trained model, next to its validation accuracy and sample count.",
    "Entry-Exit": "Entry, stop loss, targets and risk for every symbol with a signal.",
    "SL and Targets": "Only plans that passed the risk checks.",
}


def render_page():
    st.title("📋 Reports")
    st.caption("Built from your latest Big Movement scan. Run a scan first; train a model to add the AI prediction report.")
    st.warning(DISCLAIMER)
    res = st.session_state.get("bm_results")
    if res is None or len(res) == 0:
        st.info("No scan results yet. Open 🚀 Big Movement Scanner and press START SCAN.")
        return
    meta = st.session_state.get("bm_meta", {})
    st.success("Scan: %d symbols on %s, finished %s." % (len(res), meta.get("tf", "?"), meta.get("time", "?")))
    reports = build_reports(res, st.session_state.get("ml_predictions"))
    c1, c2 = st.columns(2)
    c1.download_button("⬇ Excel workbook (all reports)", to_excel_bytes(reports, {"All results": res}), "nse_reports.xlsx",
                       "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", width="stretch")
    c2.download_button("⬇ All reports as CSV (zip)", to_csv_zip_bytes({**reports, "All results": res}), "nse_reports_csv.zip", "application/zip", width="stretch")
    for name, df in reports.items():
        with st.expander("%s  (%d)" % (name, len(df)), expanded=name in ("Top Big BUY", "Top Big SELL", "Early Movement")):
            st.caption(DESCRIPTIONS.get(name, ""))
            if len(df):
                show_df(df)
                st.download_button("CSV: " + name, df.to_csv(index=False).encode("utf-8"), name.replace(" ", "_") + ".csv", "text/csv", key="dl_" + name)
            else:
                st.caption("Nothing matches right now.")
