"""Big-movement signals. Every column is causal: row t uses only bars <= t (tests verify this by truncation).

Score = transparent weighted confluence of independent conditions (0-100). It is NOT a probability.
Validated confidence combines the score with how the same kind of signal actually performed on this symbol's
own history (see validate.py).
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .data import is_intraday
from .indicators import add_indicators
from .reversal import reversal_frame
from .structure import breakout_levels, confirmed_swings, structure_state, sweeps

BUY_WEIGHTS = {"trend": 15, "momentum": 15, "acceleration": 10, "volume": 15, "volume_explosion_bonus": 5,
               "breakout_or_bos": 15, "vwap": 10, "candle": 10, "squeeze_release": 5}
STRONG_SCORE = 70
EARLY_SCORE = 45


def compute_signals(raw: pd.DataFrame, intraday: bool | None = None) -> pd.DataFrame:
    d = add_indicators(raw, intraday)
    c, a = d["Close"], d["atr"]
    sw = sweeps(d)
    d["sweep_up"], d["sweep_down"] = sw["sweep_up"], sw["sweep_down"]
    st = structure_state(d)
    d["structure"] = st
    cs = confirmed_swings(d)
    d["swing_high"], d["swing_low"] = cs["swing_high"], cs["swing_low"]
    bl = breakout_levels(d)
    d["brk_high"], d["brk_low"] = bl["brk_high"], bl["brk_low"]
    vol_ok = d["rvol"] >= 1.2
    d["breakout"] = (c > d["brk_high"]) & vol_ok
    d["breakdown"] = (c < d["brk_low"]) & vol_ok
    d["bos_up"] = c > d["swing_high"]
    d["bos_down"] = c < d["swing_low"]
    d["vol_explosion"] = d["rvol"] >= 2.5
    d["vol_surge"] = d["rvol"] >= 1.5

    mom3 = c.diff(3) / a
    accel = mom3 - mom3.shift(3)
    d["accel_up"] = (mom3 > 0.5) & (accel > 0)
    d["accel_down"] = (mom3 < -0.5) & (accel < 0)
    d["squeeze"] = (d["atr_ratio"].shift(1).rolling(5).min() < 0.8)
    expand = (d["atr_ratio"] > 1.1) & (d["atr_ratio"] > d["atr_ratio"].shift())

    # institutional-style activity ESTIMATE: heavy volume with an efficient (large, one-sided) candle.
    rng = d["High"] - d["Low"]
    d["inst_buy"] = (d["rvol"] >= 2.0) & (rng >= 1.2 * a) & (d["close_loc"] >= 0.7) & (c > d["Open"])
    d["inst_sell"] = (d["rvol"] >= 2.0) & (rng >= 1.2 * a) & (d["close_loc"] <= 0.3) & (c < d["Open"])

    f = lambda x: x.fillna(False).astype(float)
    buy = (BUY_WEIGHTS["trend"] * f((c > d["ema20"]) & (d["ema20"] > d["ema50"]))
           + BUY_WEIGHTS["momentum"] * f((d["macd_hist"] > 0) & (d["macd_hist"] > d["macd_hist"].shift()) & d["rsi"].between(52, 78))
           + BUY_WEIGHTS["acceleration"] * f(d["accel_up"])
           + BUY_WEIGHTS["volume"] * f(d["vol_surge"] & (c >= d["Open"]))
           + BUY_WEIGHTS["volume_explosion_bonus"] * f(d["vol_explosion"] & (c >= d["Open"]))
           + BUY_WEIGHTS["breakout_or_bos"] * f(d["breakout"] | (d["bos_up"] & (st >= 0)))
           + BUY_WEIGHTS["vwap"] * f(c > d["vwap"])
           + BUY_WEIGHTS["candle"] * f((d["close_loc"] >= 0.7) & (d["body_ratio"] >= 0.5) & (c > d["Open"]))
           + BUY_WEIGHTS["squeeze_release"] * f(d["squeeze"] & expand & (c > c.shift())))
    sell = (BUY_WEIGHTS["trend"] * f((c < d["ema20"]) & (d["ema20"] < d["ema50"]))
            + BUY_WEIGHTS["momentum"] * f((d["macd_hist"] < 0) & (d["macd_hist"] < d["macd_hist"].shift()) & d["rsi"].between(22, 48))
            + BUY_WEIGHTS["acceleration"] * f(d["accel_down"])
            + BUY_WEIGHTS["volume"] * f(d["vol_surge"] & (c < d["Open"]))
            + BUY_WEIGHTS["volume_explosion_bonus"] * f(d["vol_explosion"] & (c < d["Open"]))
            + BUY_WEIGHTS["breakout_or_bos"] * f(d["breakdown"] | (d["bos_down"] & (st <= 0)))
            + BUY_WEIGHTS["vwap"] * f(c < d["vwap"])
            + BUY_WEIGHTS["candle"] * f((d["close_loc"] <= 0.3) & (d["body_ratio"] >= 0.5) & (c < d["Open"]))
            + BUY_WEIGHTS["squeeze_release"] * f(d["squeeze"] & expand & (c < c.shift())))
    d["buy_score"], d["sell_score"] = buy, sell

    d["strong_buy"] = (buy >= STRONG_SCORE) & (d["adx"] >= 18) & d["vol_surge"] & (sell < 40)
    d["strong_sell"] = (sell >= STRONG_SCORE) & (d["adx"] >= 18) & d["vol_surge"] & (buy < 40)

    # EARLY: the move has not happened yet. Compression + building volume + price coiled just under/over the level.
    to_res = (d["brk_high"] - c) / a
    to_sup = (c - d["brk_low"]) / a
    base_up = d["squeeze"] & (d["rvol"] >= 1.3) & (c > d["vwap"]) & (d["ema20"] > d["ema50"]) & to_res.between(0, 0.8) & (st >= 0)
    base_dn = d["squeeze"] & (d["rvol"] >= 1.3) & (c < d["vwap"]) & (d["ema20"] < d["ema50"]) & to_sup.between(0, 0.8) & (st <= 0)
    d["early_buy"] = (base_up | (d["sweep_down"] & (d["rvol"] >= 1.5) & (c > d["Open"]))) & (buy >= EARLY_SCORE) & ~d["strong_buy"]
    d["early_sell"] = (base_dn | (d["sweep_up"] & (d["rvol"] >= 1.5) & (c < d["Open"]))) & (sell >= EARLY_SCORE) & ~d["strong_sell"]
    d["early_buy"], d["early_sell"] = d["early_buy"].fillna(False), d["early_sell"].fillna(False)

    rf = reversal_frame(d)
    d["rev_up_n"], d["rev_dn_n"] = rf["rev_up_n"], rf["rev_dn_n"]
    d["rev_up"], d["rev_dn"] = rf["rev_up_n"] >= 4, rf["rev_dn_n"] >= 4

    # historical BUY / SELL signal markers: rising edge of a strong or early signal
    raw_buy = d["strong_buy"] | d["early_buy"]
    raw_sell = d["strong_sell"] | d["early_sell"]
    d["buy_signal"] = raw_buy & ~raw_buy.shift(fill_value=False)
    d["sell_signal"] = raw_sell & ~raw_sell.shift(fill_value=False)
    return d


def label_row(r: pd.Series) -> dict:
    """Primary label for one bar (used by the scanner). Order: strong > early > reversal."""
    if r["strong_buy"]:
        return {"label": "Strong Momentum BUY", "side": "BUY"}
    if r["strong_sell"]:
        return {"label": "Strong Momentum SELL", "side": "SELL"}
    if r["early_buy"]:
        return {"label": "Early Big BUY", "side": "BUY"}
    if r["early_sell"]:
        return {"label": "Early Big SELL", "side": "SELL"}
    if r["rev_up_n"] >= 4:
        return {"label": "Reversal UP", "side": "BUY"}
    if r["rev_dn_n"] >= 4:
        return {"label": "Reversal DOWN", "side": "SELL"}
    return {"label": "No signal", "side": "NONE"}
