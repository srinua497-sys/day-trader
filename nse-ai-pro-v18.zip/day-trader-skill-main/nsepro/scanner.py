"""Big-movement universe scan: batched Yahoo downloads, background thread, checkpoint/resume.

The job runs in a daemon thread so the Streamlit page never freezes; the UI polls job.progress().
Checkpoints are written after every batch, so an interrupted scan resumes where it stopped.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
import threading
import time
from typing import Callable, Dict, List, Optional

import numpy as np
import pandas as pd

from . import data as D
from .analysis import analyze

CHECKPOINT_DIR = os.environ.get("NSEPRO_CHECKPOINT_DIR", os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".checkpoints"))
BATCH = 20


def result_row(a: dict) -> dict:
    side = a["side"]
    p = a["plans"][side]
    f, v, rev = a["flags"], a["validation"], a["reversal"]
    return {
        "Symbol": a["symbol"].replace(".NS", ""), "Yahoo": a["symbol"], "Bar time": str(a["time"])[:16], "Price": round(a["price"], 2),
        "Change %": round(a["change_pct"], 2), "Signal": a["label"], "Side": a["side"] if a["label"] != "No signal" else "",
        "Confidence (validated)": a["confidence"], "Rule score": round(a["score"], 0), "Buy score": round(a["buy_score"], 0),
        "Sell score": round(a["sell_score"], 0), "RVOL": round(a["rvol"], 2), "RSI": round(a["rsi"], 1), "ADX": round(a["adx"], 1),
        "ATR %": round(a["atr_pct"], 2), "Volume explosion": f["vol_explosion"], "Breakout": f["breakout"], "Breakdown": f["breakdown"],
        "Sweep UP": f["sweep_up"], "Sweep DOWN": f["sweep_down"], "Inst. buy est.": f["inst_buy"], "Inst. sell est.": f["inst_sell"],
        "Structure": a["structure"], "Reversal": rev["state"], "Reversal level": None if not np.isfinite(rev["level"]) else round(rev["level"], 2),
        "Breakout level": round(a["breakout_level"], 2), "Breakdown level": round(a["breakdown_level"], 2),
        "Plan side": side, "Entry": round(p["entry"], 2), "Stop loss": round(p["stop"], 2), "Target 1": round(p["t1"], 2),
        "Target 2": round(p["t2"], 2), "Target 3": round(p["t3"], 2), "Risk %": round(p["risk_pct"], 2), "R:R (T2)": p["rr_t2"],
        "Plan valid": p["valid"], "Plan note": p["invalid_reason"], "Value (Rs cr)": round(a["est_value_cr"], 2),
        "Past signals (n)": v["n"], "Past hit rate %": round(v["hit_rate"] * 100, 1), "Baseline hit %": round(v["baseline"] * 100, 1),
        "Validation": v["status"],
    }


def run_key(symbols: List[str], tf: str) -> str:
    h = hashlib.md5((",".join(sorted(symbols)) + "|" + tf).encode()).hexdigest()[:10]
    return "%s_%s" % (dt.date.today().isoformat(), h)


class ScanJob:
    def __init__(self, symbols: List[str], tf: str, resume: bool = True, fetcher: Optional[Callable] = None):
        self.symbols, self.tf, self.resume = list(symbols), tf, resume
        self.fetcher = fetcher or (lambda syms, tf_: D.get_history_batch(syms, tf_))
        self.rows: List[dict] = []
        self.errors: List[dict] = []
        self.done = 0
        self.status = "idle"            # idle | running | finished | stopped | failed
        self.message = ""
        self._stop = threading.Event()
        self._lock = threading.Lock()
        self.thread: Optional[threading.Thread] = None
        self.key = run_key(self.symbols, tf)
        self.path = os.path.join(CHECKPOINT_DIR, "scan_%s.json" % self.key)
        self.resumed = 0
        self.started = 0.0
        self.finished_at = 0.0

    def _load(self):
        try:
            with open(self.path) as fh:
                saved = json.load(fh)
            self.rows, self.errors = saved.get("rows", []), saved.get("errors", [])
            self.resumed = len(self.rows) + len(self.errors)
        except Exception:
            self.rows, self.errors, self.resumed = [], [], 0

    def _save(self):
        try:
            os.makedirs(CHECKPOINT_DIR, exist_ok=True)
            tmp = self.path + ".tmp"
            with open(tmp, "w") as fh:
                json.dump({"rows": self.rows, "errors": self.errors, "tf": self.tf}, fh, default=str)
            os.replace(tmp, self.path)
        except Exception:
            pass  # checkpointing is best effort (read-only filesystems)

    def start(self):
        if self.thread and self.thread.is_alive():
            return
        if self.resume:
            self._load()
        else:
            self.rows, self.errors, self.resumed = [], [], 0
        self.started = time.time()
        self.status = "running"
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def stop(self):
        self._stop.set()

    def _run(self):
        try:
            finished = {r["Yahoo"] for r in self.rows} | {e["Yahoo"] for e in self.errors}
            todo = [s for s in self.symbols if s not in finished]
            self.done = len(self.symbols) - len(todo)
            for i in range(0, len(todo), BATCH):
                if self._stop.is_set():
                    self.status = "stopped"
                    self.message = "Stopped. Progress is saved; start again to resume."
                    self._save()
                    return
                chunk = todo[i:i + BATCH]
                self.message = "Downloading %d-%d of %d" % (i + 1, i + len(chunk), len(todo))
                try:
                    frames = self.fetcher(chunk, self.tf)
                except Exception as exc:
                    # network trouble: do NOT mark symbols as failed forever, leave them for a later resume
                    self.status, self.message = "failed", "Yahoo Finance request failed: %s" % exc
                    self._save()
                    return
                for s in chunk:
                    f = frames.get(s)
                    if f is None or len(f) == 0:
                        self.errors.append({"Yahoo": s, "Error": "No data from Yahoo Finance (delisted, wrong symbol or rate limited)"})
                    else:
                        try:
                            self.rows.append(result_row(analyze(s, f)))
                        except Exception as exc:
                            self.errors.append({"Yahoo": s, "Error": str(exc)})
                    self.done += 1
                self._save()
            self.status = "finished"
            self.message = "Scan complete"
            self.finished_at = time.time()
        except Exception as exc:  # never let the thread die silently
            self.status, self.message = "failed", "Unexpected error: %s" % exc

    def progress(self) -> dict:
        total = max(len(self.symbols), 1)
        return {"status": self.status, "done": self.done, "total": total, "fraction": min(self.done / total, 1.0),
                "message": self.message, "ok": len(self.rows), "failed": len(self.errors), "resumed": self.resumed,
                "elapsed": (time.time() - self.started) if self.started else 0.0}

    def results(self) -> pd.DataFrame:
        df = pd.DataFrame(list(self.rows))
        return df

    def failures(self) -> pd.DataFrame:
        return pd.DataFrame(list(self.errors))
