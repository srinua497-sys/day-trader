"""AI Model page: train, walk-forward validate, backtest and predict with real trained models."""
from __future__ import annotations

import numpy as np
import pandas as pd
import streamlit as st

from . import data as D
from . import ml
from .ui_common import DISCLAIMER, show_chart, show_df, universe_picker


def _train_ui(tf: str, syms, model_name: str, targets, folds: int, cost_bps: float, thr: float):
    prog = st.progress(0.0, text="Downloading history from Yahoo Finance...")
    frames = {}
    try:
        for i in range(0, len(syms), 20):
            frames.update(D.get_history_batch(syms[i:i + 20], tf))
            prog.progress(min(0.3 * (i + 20) / max(len(syms), 1), 0.3), text="Downloaded %d/%d symbols" % (min(i + 20, len(syms)), len(syms)))
    except Exception as exc:
        prog.empty()
        st.error("Yahoo Finance download failed: %s" % exc)
        return
    frames = {s: f for s, f in frames.items() if len(f) >= ml.WARMUP + 60}
    if len(frames) < 1:
        prog.empty()
        st.error("No symbol returned enough history (need %d+ candles). Try a different timeframe or symbols." % (ml.WARMUP + 60))
        return
    results = {}
    for j, tg in enumerate(targets):
        prog.progress(0.3 + 0.7 * j / len(targets), text="Training and walk-forward validating: %s (%s)" % (ml.TARGETS[tg][0], model_name))
        try:
            results[tg] = ml.train_and_validate(frames, tf, tg, model_name, folds, cost_bps, thr)
        except Exception as exc:
            results[tg] = {"error": str(exc)}
    prog.progress(1.0, text="Done")
    st.session_state["ml_results"] = {"tf": tf, "model": model_name, "symbols": sorted(frames), "results": results, "cost_bps": cost_bps, "thr": thr}


def _show_result(tg: str, r: dict, tf: str):
    title = ml.TARGETS[tg][0]
    if "error" in r:
        st.error("%s: %s" % (title, r["error"]))
        return
    b, wf = r["bundle"], r["wf"]
    s = b["summary"]
    st.markdown("#### %s" % title)
    if s["has_edge"]:
        st.success("Out-of-sample accuracy beat the baseline and AUC is above 0.52. That is weak evidence of a pattern, not a guarantee.")
    else:
        st.warning("**No demonstrated edge.** Out-of-sample accuracy did not beat a naive baseline by 1 point, or AUC is below 0.52. Do not trade on this model's probabilities.")
    c = st.columns(5)
    c[0].metric("Validation accuracy (OOS)", "%.1f%%" % (s["oos_accuracy"] * 100))
    c[1].metric("Naive baseline", "%.1f%%" % (s["baseline_accuracy"] * 100))
    c[2].metric("AUC (OOS)", "%.3f" % s["oos_auc"])
    c[3].metric("Validation samples", "{:,}".format(s["oos_samples"]))
    c[4].metric("Training samples (final fit)", "{:,}".format(b["n_fit"]))
    show_df(wf["folds"].assign(accuracy=lambda x: (x.accuracy * 100).round(1), baseline_accuracy=lambda x: (x.baseline_accuracy * 100).round(1), auc=lambda x: x.auc.round(3)))
    if tg in ("up3", "up6"):
        bt = b["backtest"]
        if bt.get("trades", 0) == 0:
            st.info("No out-of-sample trades crossed the probability threshold.")
        else:
            st.caption("Backtest on out-of-sample predictions only. Entry at the next candle open, exit after the horizon, round-trip cost %.0f bps, one position per symbol, shorts %s." % (
                bt["cost_bps"], "allowed (intraday)" if D.TIMEFRAMES[tf][2] < 1440 else "not allowed (daily)"))
            c = st.columns(6)
            c[0].metric("Trades", bt["trades"]); c[1].metric("Win rate", "%.1f%%" % (bt["win_rate"] * 100))
            c[2].metric("Avg net / trade", "%.1f bps" % bt["avg_net_bps"]); c[3].metric("Total net", "%.1f%%" % bt["total_net_pct"])
            c[4].metric("Max drawdown", "%.1f%%" % bt["max_drawdown_pct"]); c[5].metric("t-stat", "%.2f" % bt["t_stat"])
            tr = ml.backtest(wf["oos"], tg, bt["threshold"], bt["cost_bps"], D.TIMEFRAMES[tf][2] < 1440)["trades"]
            if len(tr):
                st.line_chart(tr.assign(cumulative_net_pct=tr["net"].cumsum() * 100).set_index("time")["cumulative_net_pct"])
    else:
        lift = b["lift"]
        st.write("Among the 10%% highest-probability out-of-sample rows (%d), the event happened %.1f%% of the time versus a %.1f%% base rate (lift %.2fx)." % (
            lift["n_top"], lift["top_decile_rate"] * 100, lift["base_rate"] * 100, lift["lift"]))
    if len(r["importance"]):
        with st.expander("Feature importance"):
            st.bar_chart(r["importance"].head(15).set_index("feature"))


def render_page():
    st.title("🤖 AI Model (trainable ML)")
    st.caption("XGBoost / Random Forest / LightGBM trained on historical Yahoo Finance OHLCV. Time-based walk-forward validation with an embargo gap, costs included.")
    st.warning(DISCLAIMER)
    st.info("Nothing here is pre-trained or invented. A model only exists after you train it below, and every probability is shown next to its out-of-sample validation accuracy and sample counts. "
            "On Yahoo's limited intraday history (about 60 days) most models find no real edge, and the app tells you when that happens.")
    t1, t2 = st.columns(2)
    with t1:
        tf = st.selectbox("Timeframe", list(D.TIMEFRAMES), index=1, key="ml_tf")
        model_name = st.selectbox("Algorithm", ml.available_models(), key="ml_model")
    with t2:
        targets = st.multiselect("Targets", list(ml.TARGETS), default=list(ml.TARGETS), format_func=lambda k: ml.TARGETS[k][0], key="ml_targets")
        folds = st.slider("Walk-forward folds", 3, 8, 5, key="ml_folds")
    cb, th = st.columns(2)
    cost = cb.number_input("Round-trip cost (bps: brokerage, STT, charges, slippage)", 0.0, 200.0, 10.0 if D.TIMEFRAMES[tf][2] < 1440 else 25.0, 1.0, key="ml_cost")
    thr = th.slider("Trade threshold (probability)", 0.50, 0.75, 0.55, 0.01, key="ml_thr")
    syms = universe_picker("ml", default_n=30)
    if st.button("🏋 TRAIN AND VALIDATE", type="primary", disabled=not targets):
        _train_ui(tf, syms, model_name, targets, folds, cost, thr)
    out = st.session_state.get("ml_results")
    if out:
        st.subheader("Latest training run: %s, %s, %d symbols" % (out["tf"], out["model"], len(out["symbols"])))
        tabs = st.tabs([ml.TARGETS[t][0] for t in out["results"]])
        for tab, (tg, r) in zip(tabs, out["results"].items()):
            with tab:
                _show_result(tg, r, out["tf"])

    st.divider()
    st.subheader("Predict with a saved model")
    tg = st.selectbox("Target", list(ml.TARGETS), format_func=lambda k: ml.TARGETS[k][0], key="ml_pred_target")
    bundle = ml.load_bundle(tf, tg, model_name)
    if not bundle:
        st.info("No saved %s model for %s / %s. Train it above first." % (model_name, tf, ml.TARGETS[tg][0]))
        return
    s = bundle["summary"]
    st.caption("Saved model trained %s on %d symbols. Validation accuracy %.1f%% (baseline %.1f%%), %s validation samples, %s training samples. %s" % (
        bundle["trained_at"], bundle["n_symbols"], s["oos_accuracy"] * 100, s["baseline_accuracy"] * 100, "{:,}".format(s["oos_samples"]), "{:,}".format(bundle["n_fit"]),
        "Edge demonstrated (weak)." if s["has_edge"] else "NO demonstrated edge."))
    scan = st.session_state.get("bm_results")
    default_syms = list(scan["Yahoo"].head(25)) if scan is not None and len(scan) else syms[:25]
    pick = st.multiselect("Symbols to predict", syms, default=[x for x in default_syms if x in syms] or syms[:10], key="ml_pred_syms")
    if st.button("Predict latest candle") and pick:
        with st.spinner("Fetching and predicting..."):
            try:
                frames = D.get_history_batch(pick, tf)
                pr = ml.predict_latest(bundle, frames)
            except Exception as exc:
                st.error("Prediction failed: %s" % exc)
                return
        if pr.empty:
            st.warning("No symbol had enough data.")
            return
        directional = tg in ("up3", "up6")
        tbl = pd.DataFrame({"Symbol": pr["Symbol"].str.replace(".NS", "", regex=False), "Bar time": pr["Bar time"].astype(str).str[:16], "Price": pr["Price"].round(2)})
        if directional:
            tbl["UP probability %"] = (pr["p_event"] * 100).round(1)
            tbl["DOWN probability %"] = ((1 - pr["p_event"]) * 100).round(1)
        else:
            tbl["Event probability %"] = (pr["p_event"] * 100).round(1)
            tbl["Base rate %"] = round(s["positive_rate"] * 100, 1)
        tbl["Validation accuracy %"] = round(s["oos_accuracy"] * 100, 1)
        tbl["Validation samples"] = s["oos_samples"]
        tbl["Edge demonstrated"] = "yes (weak)" if s["has_edge"] else "NO"
        tbl.insert(1, "Model", "%s / %s / %s" % (ml.TARGETS[tg][0], model_name, tf))
        show_df(tbl.sort_values(tbl.columns[4], ascending=False))
        st.session_state["ml_predictions"] = tbl
