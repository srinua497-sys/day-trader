"""Interactive Plotly chart: candles, EMA20/50/200, VWAP, volume, S/R, trade levels and signal markers."""
from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from .structure import structure_labels


def _naive(idx):
    i = pd.DatetimeIndex(idx)
    return i.tz_localize(None) if i.tz is not None else i


def build_chart(d: pd.DataFrame, analysis: dict, bars: int = 160, show: dict | None = None) -> go.Figure:
    show = {"ema": True, "vwap": True, "sr": True, "levels": True, "signals": True, "structure": False, "markers": True, **(show or {})}
    v = d.iloc[-bars:]
    x = _naive(v.index)
    intraday = analysis["intraday"]
    fig = make_subplots(rows=2, cols=1, shared_xaxes=True, row_heights=[0.76, 0.24], vertical_spacing=0.02)
    fig.add_trace(go.Candlestick(x=x, open=v["Open"], high=v["High"], low=v["Low"], close=v["Close"], name="Price",
                                 increasing_line_color="#26a69a", decreasing_line_color="#ef5350"), row=1, col=1)
    if show["ema"]:
        for col, color, w in (("ema20", "#f9a825", 1.2), ("ema50", "#42a5f5", 1.2), ("ema200", "#ab47bc", 1.4)):
            fig.add_trace(go.Scatter(x=x, y=v[col], name=col.upper().replace("EMA", "EMA "), line=dict(color=color, width=w)), row=1, col=1)
    if show["vwap"]:
        fig.add_trace(go.Scatter(x=x, y=v["vwap"], name="VWAP", line=dict(color="#90a4ae", width=1.4, dash="dot")), row=1, col=1)
    colors = np.where(v["Close"] >= v["Open"], "#26a69a", "#ef5350")
    fig.add_trace(go.Bar(x=x, y=v["Volume"], marker_color=colors, name="Volume", opacity=0.7), row=2, col=1)
    fig.add_trace(go.Scatter(x=x, y=v["Volume"].rolling(20, min_periods=1).mean(), name="Vol avg 20", line=dict(color="#ffa726", width=1)), row=2, col=1)

    lv = analysis["levels"]
    x0, x1 = x[0], x[-1]
    if show["sr"]:
        for p in lv["support"][:3]:
            fig.add_hline(y=p, line=dict(color="#2e7d32", width=1, dash="dash"), annotation_text="Support %.2f" % p, annotation_position="bottom left", row=1, col=1)
        for p in lv["resistance"][:3]:
            fig.add_hline(y=p, line=dict(color="#c62828", width=1, dash="dash"), annotation_text="Resistance %.2f" % p, annotation_position="top left", row=1, col=1)
        for p in lv["liq_buy"][:2]:
            fig.add_hrect(y0=p - analysis["atr"] * 0.15, y1=p + analysis["atr"] * 0.15, fillcolor="rgba(46,125,50,0.15)", line_width=0, row=1, col=1)
        for p in lv["liq_sell"][:2]:
            fig.add_hrect(y0=p - analysis["atr"] * 0.15, y1=p + analysis["atr"] * 0.15, fillcolor="rgba(198,40,40,0.15)", line_width=0, row=1, col=1)
        for p, lbl in ((analysis["breakout_level"], "Breakout"), (analysis["breakdown_level"], "Breakdown")):
            if np.isfinite(p):
                fig.add_hline(y=p, line=dict(color="#ff9800", width=1, dash="longdash"), annotation_text="%s %.2f" % (lbl, p), annotation_position="top right", row=1, col=1)
    if show["levels"]:
        for side, col in (("BUY", "#00c853"), ("SELL", "#ff1744")):
            p = analysis["plans"][side]
            tag = "" if p["valid"] else " (invalid)"
            for key, name, dash in (("entry", "%s entry" % side, "solid"), ("stop", "%s SL" % side, "dot"), ("t1", "%s T1" % side, "dash"),
                                    ("t2", "%s T2" % side, "dash"), ("t3", "%s T3" % side, "dash")):
                fig.add_shape(type="line", x0=x[max(0, len(x) - 40)], x1=x1, y0=p[key], y1=p[key], line=dict(color=col, width=1.3, dash=dash),
                              opacity=1.0 if p["valid"] else 0.45, row=1, col=1)
                fig.add_annotation(x=x1, y=p[key], text="%s %.2f%s" % (name, p[key], tag), showarrow=False, xanchor="left",
                                   font=dict(color=col, size=10), row=1, col=1)
    if show["markers"]:
        def mark(mask, ycol, sym, color, name, off):
            m = mask.iloc[-bars:].fillna(False).to_numpy()
            if m.any():
                y = v[ycol].to_numpy()[m] * (1 + off)
                fig.add_trace(go.Scatter(x=x[m], y=y, mode="markers", name=name, marker=dict(symbol=sym, size=9, color=color,
                              line=dict(width=0.5, color="#222"))), row=1, col=1)
        mark(v["breakout"], "High", "triangle-up", "#ffd600", "Breakout", 0.002)
        mark(v["breakdown"], "Low", "triangle-down", "#ff6d00", "Breakdown", -0.002)
        mark(v["sweep_down"], "Low", "diamond", "#00e5ff", "Liquidity sweep DOWN", -0.003)
        mark(v["sweep_up"], "High", "diamond", "#e040fb", "Liquidity sweep UP", 0.003)
        mark(v["rev_up"], "Low", "star", "#69f0ae", "Reversal UP", -0.005)
        mark(v["rev_dn"], "High", "star", "#ff8a80", "Reversal DOWN", 0.005)
    if show["signals"]:
        def sig(mask, ycol, sym, color, name, off):
            m = mask.iloc[-bars:].fillna(False).to_numpy()
            if m.any():
                fig.add_trace(go.Scatter(x=x[m], y=v[ycol].to_numpy()[m] * (1 + off), mode="markers+text", text=[name.split()[0]] * int(m.sum()),
                              textposition="bottom center" if "BUY" in name else "top center", name=name,
                              marker=dict(symbol=sym, size=13, color=color, line=dict(width=1, color="white"))), row=1, col=1)
        sig(v["buy_signal"], "Low", "triangle-up", "#00c853", "BUY signal (history)", -0.008)
        sig(v["sell_signal"], "High", "triangle-down", "#ff1744", "SELL signal (history)", 0.008)
    if show["structure"]:
        lab = [l for l in structure_labels(d.iloc[-bars:])]
        if lab:
            fig.add_trace(go.Scatter(x=[_naive([l["time"]])[0] for l in lab], y=[l["price"] for l in lab], mode="text", text=[l["label"] for l in lab],
                                     textposition=["top center" if l["kind"] == "high" else "bottom center" for l in lab], name="Structure", showlegend=True), row=1, col=1)
    breaks = [dict(bounds=["sat", "mon"])]
    if intraday:
        breaks.append(dict(bounds=[15.5, 9.25], pattern="hour"))
    fig.update_xaxes(rangebreaks=breaks, rangeslider_visible=False)
    fig.update_layout(height=760, template="plotly_dark", margin=dict(l=10, r=130, t=40, b=10), legend=dict(orientation="h", y=1.04),
                      title="%s  |  %s" % (analysis["symbol"], "intraday" if intraday else "daily"), hovermode="x unified")
    return fig
