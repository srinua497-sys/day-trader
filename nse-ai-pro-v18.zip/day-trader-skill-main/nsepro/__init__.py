"""NSE AI PRO: Yahoo Finance based big-movement detection, stock analysis and ML.

Everything here is transparent, rule based or trained on historical Yahoo OHLCV data.
Nothing in this package places orders or claims guaranteed predictions.
"""
__version__ = "18.0.0"
