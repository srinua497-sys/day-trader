"""ATR + market-structure trade plans with Risk/Reward validation. Plans are analysis, not orders."""
from __future__ import annotations

import numpy as np
import pandas as pd

from .structure import key_levels

MAX_RISK_PCT = {"intraday": 2.0, "daily": 6.0}
MIN_RR_T2 = 1.5


def trade_plan(d: pd.DataFrame, side: str, intraday: bool, levels: dict | None = None, i: int = -1) -> dict:
    """d needs signals columns. side BUY or SELL. Entry is the current close if the trigger already printed,
    otherwise a stop-entry beyond the breakout / breakdown level."""
    row = d.iloc[i]
    a = float(row["atr"])
    close = float(row["Close"])
    sgn = 1 if side == "BUY" else -1
    levels = levels or key_levels(d.iloc[: (len(d) + i + 1) if i < 0 else i + 1])
    trig = float(row["brk_high"] if side == "BUY" else row["brk_low"])
    triggered = bool(row["breakout"] if side == "BUY" else row["breakdown"]) or bool(row["bos_up"] if side == "BUY" else row["bos_down"])
    if triggered or not np.isfinite(trig):
        entry = close
    else:
        entry = trig + sgn * 0.05 * a  # stop-entry just beyond the level
    swing = float(row["swing_low"] if side == "BUY" else row["swing_high"])
    atr_stop = entry - sgn * 1.5 * a
    struct_stop = swing - sgn * 0.25 * a if np.isfinite(swing) else atr_stop
    # the tighter of the two (closer to entry), but never closer than 0.8 ATR (noise) and never farther than 3 ATR
    cand = [atr_stop, struct_stop]
    sl = max(cand) if side == "BUY" else min(cand)
    sl = min(sl, entry - 0.8 * a) if side == "BUY" else max(sl, entry + 0.8 * a)
    sl = max(sl, entry - 3 * a) if side == "BUY" else min(sl, entry + 3 * a)
    risk = abs(entry - sl)
    t1, t2, t3 = (entry + sgn * m * risk for m in (1.0, 2.0, 3.0))
    risk_pct = risk / entry * 100 if entry else np.nan
    cap = MAX_RISK_PCT["intraday" if intraday else "daily"]
    nearest = (levels["resistance"] if side == "BUY" else levels["support"])
    room = abs(nearest[0] - entry) / risk if nearest and risk else np.nan
    reasons = []
    if risk_pct > cap:
        reasons.append("risk %.2f%% of price exceeds the %.1f%% cap" % (risk_pct, cap))
    if risk > 3 * a + 1e-9:
        reasons.append("stop is wider than 3 ATR")
    rr_t2 = 2.0
    if np.isfinite(room) and room < 0.75:
        reasons.append("nearest %s is only %.1fR away" % ("resistance" if side == "BUY" else "support", room))
    valid = not reasons
    trail_dist = 2.0 * a
    window = d.iloc[-10:]
    trail_now = float(window["High"].max() - trail_dist) if side == "BUY" else float(window["Low"].min() + trail_dist)
    exit_conf = ("Exit on a close below the trailing stop %.2f, or EMA20 lost with MACD histogram negative, or a REVERSAL DOWN state"
                 if side == "BUY" else
                 "Exit on a close above the trailing stop %.2f, or EMA20 reclaimed with MACD histogram positive, or a REVERSAL UP state") % trail_now
    entry_conf = (("Close above %.2f with RVOL >= 1.2, price above VWAP" if side == "BUY" else "Close below %.2f with RVOL >= 1.2, price below VWAP") % entry)
    if triggered:
        entry_conf = "Trigger already printed on the last completed bar. " + entry_conf
    return {"side": side, "entry": entry, "stop": sl, "t1": t1, "t2": t2, "t3": t3, "risk": risk, "risk_pct": risk_pct,
            "rr_t1": 1.0, "rr_t2": rr_t2, "rr_t3": 3.0, "room_to_level_R": room, "valid": valid,
            "invalid_reason": "; ".join(reasons), "trail_initial": entry - sgn * trail_dist,
            "trail_now": trail_now, "breakeven_rule": "Move stop to entry after Target 1; trail at Target 1 after Target 2",
            "entry_confirmation": entry_conf, "exit_confirmation": exit_conf, "triggered": triggered,
            "atr": a}
