"""Market structure: swings, HH/HL/LH/LL, support/resistance, liquidity zones and sweeps.

Swing points are only *confirmed* k bars after they form, and every per-bar series below is aligned to the
confirmation bar, so nothing here looks into the future.
"""
from __future__ import annotations

from typing import Dict, List

import numpy as np
import pandas as pd

K = 3  # bars on each side that must be lower/higher to confirm a swing


def swing_points(df: pd.DataFrame, k: int = K):
    """Return boolean arrays (is_swing_high, is_swing_low) positioned at the swing bar (not the confirmation bar)."""
    h, l = df["High"].to_numpy(float), df["Low"].to_numpy(float)
    n = len(df)
    sh, sl = np.zeros(n, bool), np.zeros(n, bool)
    for i in range(k, n - k):
        if h[i] >= h[i - k:i + k + 1].max() and h[i] > h[i - 1] - 1e-12:
            sh[i] = True
        if l[i] <= l[i - k:i + k + 1].min() and l[i] < l[i - 1] + 1e-12:
            sl[i] = True
    return sh, sl


def confirmed_swings(df: pd.DataFrame, k: int = K) -> pd.DataFrame:
    """Per-bar last confirmed swing high/low price, available only from bar (swing + k)."""
    sh, sl = swing_points(df, k)
    hi = pd.Series(np.where(sh, df["High"].to_numpy(), np.nan), index=df.index).shift(k).ffill()
    lo = pd.Series(np.where(sl, df["Low"].to_numpy(), np.nan), index=df.index).shift(k).ffill()
    # previous (second last) confirmed swing, for HH/LH/HL/LL classification
    hi_vals = pd.Series(np.where(sh, df["High"].to_numpy(), np.nan), index=df.index)
    lo_vals = pd.Series(np.where(sl, df["Low"].to_numpy(), np.nan), index=df.index)
    prev_hi = hi_vals.dropna()
    prev_lo = lo_vals.dropna()
    ph = pd.Series(prev_hi.shift(1).reindex(df.index), index=df.index).shift(k).ffill()
    pl = pd.Series(prev_lo.shift(1).reindex(df.index), index=df.index).shift(k).ffill()
    out = pd.DataFrame({"swing_high": hi, "swing_low": lo, "prev_swing_high": ph, "prev_swing_low": pl})
    return out


def structure_labels(df: pd.DataFrame, k: int = K) -> List[dict]:
    """HH / LH labels for swing highs and HL / LL for swing lows (for chart markers; positioned at the swing bar)."""
    sh, sl = swing_points(df, k)
    labels, last_h, last_l = [], None, None
    for i in range(len(df)):
        if sh[i]:
            v = float(df["High"].iloc[i])
            if last_h is not None:
                labels.append({"time": df.index[i], "price": v, "label": "HH" if v > last_h else "LH", "kind": "high"})
            last_h = v
        if sl[i]:
            v = float(df["Low"].iloc[i])
            if last_l is not None:
                labels.append({"time": df.index[i], "price": v, "label": "HL" if v > last_l else "LL", "kind": "low"})
            last_l = v
    return labels


def structure_state(df: pd.DataFrame, k: int = K) -> pd.Series:
    """+1 uptrend (higher high and higher low), -1 downtrend (lower high and lower low), 0 range. Causal."""
    s = confirmed_swings(df, k)
    up = (s["swing_high"] > s["prev_swing_high"]) & (s["swing_low"] > s["prev_swing_low"])
    dn = (s["swing_high"] < s["prev_swing_high"]) & (s["swing_low"] < s["prev_swing_low"])
    return pd.Series(np.where(up, 1, np.where(dn, -1, 0)), index=df.index)


def structure_name(v: int) -> str:
    return {1: "UPTREND (HH/HL)", -1: "DOWNTREND (LH/LL)", 0: "RANGE / MIXED"}[int(v)]


def breakout_levels(df: pd.DataFrame, n: int = 20) -> pd.DataFrame:
    """Prior n-bar high/low (excluding the current bar)."""
    return pd.DataFrame({"brk_high": df["High"].shift(1).rolling(n, min_periods=5).max(),
                         "brk_low": df["Low"].shift(1).rolling(n, min_periods=5).min()})


def sweeps(df: pd.DataFrame, k: int = K) -> pd.DataFrame:
    """Liquidity sweep: wick through the last confirmed swing point, close back inside."""
    s = confirmed_swings(df, k)
    up = (df["High"] > s["swing_high"]) & (df["Close"] < s["swing_high"])
    dn = (df["Low"] < s["swing_low"]) & (df["Close"] > s["swing_low"])
    return pd.DataFrame({"sweep_up": up.fillna(False), "sweep_down": dn.fillna(False)})


def key_levels(df: pd.DataFrame, k: int = K, lookback: int = 300, tol_atr: float = 0.5) -> Dict[str, list]:
    """Support / resistance: clusters of swing points within tol_atr*ATR. Also equal-high / equal-low
    liquidity pools (2+ touches): resting stop orders that price is often drawn to and swept."""
    d = df.iloc[-lookback:]
    if len(d) < 3 * k + 2:
        return {"support": [], "resistance": [], "liq_buy": [], "liq_sell": []}
    atr_v = float(df["atr"].iloc[-1]) if "atr" in df else float((d["High"] - d["Low"]).mean())
    tol = max(atr_v * tol_atr, 1e-9)
    sh, sl = swing_points(d, k)
    last = float(d["Close"].iloc[-1])

    def cluster(vals):
        vals = sorted(vals)
        groups = []
        for v in vals:
            if groups and abs(v - np.mean(groups[-1])) <= tol:
                groups[-1].append(v)
            else:
                groups.append([v])
        return [(float(np.mean(g)), len(g)) for g in groups]

    hi_cl = cluster(d["High"].to_numpy()[sh])
    lo_cl = cluster(d["Low"].to_numpy()[sl])
    allc = hi_cl + lo_cl
    support = sorted([p for p, _ in allc if p < last], reverse=True)
    resistance = sorted([p for p, _ in allc if p > last])
    # liquidity pools: 2+ equal highs (sell-side stops rest above, a "liquidity SELL zone" where a sweep can reverse down)
    liq_sell = sorted([p for p, n in hi_cl if n >= 2 and p > last])
    liq_buy = sorted([p for p, n in lo_cl if n >= 2 and p < last], reverse=True)
    return {"support": support[:4], "resistance": resistance[:4], "liq_buy": liq_buy[:3], "liq_sell": liq_sell[:3]}
