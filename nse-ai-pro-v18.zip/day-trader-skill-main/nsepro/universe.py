"""Symbol lists and symbol cleaning for NSE (Yahoo Finance tickers end in .NS)."""
from __future__ import annotations

import re

NIFTY50 = [
    "RELIANCE", "HDFCBANK", "ICICIBANK", "INFY", "TCS", "BHARTIARTL", "ITC", "SBIN", "LT", "KOTAKBANK",
    "AXISBANK", "HINDUNILVR", "BAJFINANCE", "MARUTI", "SUNPHARMA", "TITAN", "ULTRACEMCO", "NTPC",
    "ONGC", "POWERGRID", "ASIANPAINT", "WIPRO", "HCLTECH", "M&M", "TATASTEEL", "JSWSTEEL", "ADANIENT",
    "ADANIPORTS", "COALINDIA", "BAJAJFINSV", "NESTLEIND", "TECHM", "GRASIM", "HINDALCO", "CIPLA",
    "DRREDDY", "EICHERMOT", "BRITANNIA", "APOLLOHOSP", "TATACONSUM", "SBILIFE", "HDFCLIFE", "BPCL",
    "HEROMOTOCO", "INDUSINDBK", "SHRIRAMFIN", "TRENT", "BEL", "ETERNAL", "JIOFIN",
]
NEXT_LIQUID = [
    "BANKBARODA", "PNB", "CANBK", "UNIONBANK", "IDFCFIRSTB", "FEDERALBNK", "BANDHANBNK", "AUBANK",
    "VEDL", "SAIL", "NMDC", "JINDALSTEL", "HAL", "BHEL", "IRCTC", "RECLTD", "PFC", "IOC", "GAIL",
    "TATAPOWER", "ADANIPOWER", "ADANIGREEN", "DLF", "GODREJPROP", "LODHA", "PIDILITIND", "SIEMENS",
    "ABB", "HAVELLS", "POLYCAB", "DABUR", "MARICO", "COLPAL", "GODREJCP", "AMBUJACEM", "SHREECEM",
    "LUPIN", "AUROPHARMA", "TORNTPHARM", "ZYDUSLIFE", "BIOCON", "MUTHOOTFIN", "CHOLAFIN", "BAJAJ-AUTO",
    "TVSMOTOR", "ASHOKLEY", "BOSCHLTD", "MOTHERSON", "PERSISTENT", "COFORGE", "MPHASIS", "LTIM",
    "NAUKRI", "DMART", "INDIGO", "TATAELXSI", "DIXON", "PAYTM", "ZOMATO", "IDEA", "YESBANK",
]
INDEX_MAP = {"NIFTY 50": "^NSEI", "BANK NIFTY": "^NSEBANK", "INDIA VIX": "^INDIAVIX"}


def clean_symbol(s: str) -> str:
    """'reliance', 'NSE:RELIANCE-EQ', 'RELIANCE.NS' -> 'RELIANCE.NS'. Indices (^NSEI) are kept."""
    s = (s or "").strip().upper()
    if not s:
        return ""
    if s.startswith("NSE:"):
        s = s[4:]
    s = re.sub(r"-(EQ|BE)$", "", s)
    if s.startswith("^") or s.endswith((".NS", ".BO")):
        return s
    if re.fullmatch(r"[A-Z0-9&_-]+", s):
        return s + ".NS"
    return ""


def to_yahoo(symbols) -> list:
    out = []
    for s in symbols:
        c = clean_symbol(s)
        if c and c not in out:
            out.append(c)
    return out


UNIVERSES = {
    "Nifty 50": to_yahoo(NIFTY50),
    "Nifty 50 + liquid next-line (about 110)": to_yahoo(NIFTY50 + NEXT_LIQUID),
}
