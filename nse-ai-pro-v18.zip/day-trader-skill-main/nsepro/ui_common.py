"""Small Streamlit helpers shared by the new pages."""
from __future__ import annotations

import pandas as pd
import streamlit as st

from .universe import UNIVERSES, clean_symbol, to_yahoo

DISCLAIMER = ("Yahoo Finance is an unofficial source: data can be delayed, incomplete or rate limited, and the app only uses completed "
              "candles. Signals are rule based analysis and statistical models trained on past data, not guaranteed predictions or "
              "financial advice. Nothing in this app places orders.")


def show_df(df: pd.DataFrame, **kw):
    try:
        st.dataframe(df, width="stretch", hide_index=True, **kw)
    except Exception:
        st.dataframe(df, use_container_width=True, hide_index=True, **kw)


def show_chart(fig, **kw):
    try:
        st.plotly_chart(fig, width="stretch", **kw)
    except Exception:
        st.plotly_chart(fig, use_container_width=True, **kw)


def goto(page: str, **state):
    """Callback: switch the sidebar page and stash values for the target page."""
    st.session_state.update(state)
    st.session_state["main_page"] = page


def universe_picker(key: str, default_n: int = 50):
    """Returns the list of Yahoo symbols chosen by preset or by pasted custom list."""
    c1, c2 = st.columns([1, 2])
    with c1:
        preset = st.selectbox("Universe", list(UNIVERSES) + ["Custom list"], key=key + "_preset")
    base = UNIVERSES.get(preset, UNIVERSES["Nifty 50"])
    with c2:
        text = st.text_area("NSE symbols (comma separated)", ", ".join(s.replace(".NS", "") for s in base) if preset != "Custom list" else "RELIANCE, TCS, INFY, HDFCBANK",
                            height=80, key=key + "_text_" + preset)
    syms = to_yahoo([x for x in text.replace("\n", ",").split(",") if x.strip()])
    if len(syms) <= 5:
        return syms
    n = st.slider("Maximum symbols to use", 5, len(syms), min(default_n, len(syms)), 1, key=key + "_max")
    return syms[:n]
