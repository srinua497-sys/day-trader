"""Run this on a machine with internet access to verify live Yahoo Finance retrieval for NSE.

    python tools/verify_yahoo.py            # checks a few NSE symbols on every timeframe the app uses
    python tools/verify_yahoo.py TCS INFY   # your own symbols

It uses the same data layer as the app, so a pass here means the app can fetch, clean and analyse live data.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from nsepro import data as D          # noqa: E402
from nsepro.analysis import analyze   # noqa: E402
from nsepro.universe import to_yahoo  # noqa: E402


def main(argv):
    syms = to_yahoo(argv or ["RELIANCE", "TCS", "HDFCBANK"])
    ok = True
    for tf in D.TIMEFRAMES:
        try:
            got = D.get_history_batch(syms, tf, use_cache=False)
        except Exception as exc:
            print("FAIL %-7s download error: %s" % (tf, exc)); ok = False; continue
        for s in syms:
            f = got.get(s)
            if f is None or len(f) == 0:
                print("FAIL %-7s %-14s no data" % (tf, s)); ok = False; continue
            try:
                a = analyze(s, f)
                print("ok   %-7s %-14s %4d bars, last %s  close %.2f  signal: %s" % (tf, s, len(f), str(f.index[-1])[:16], f["Close"].iloc[-1], a["label"]))
            except Exception as exc:
                print("FAIL %-7s %-14s analysis error: %s" % (tf, s, exc)); ok = False
    print("\nRESULT:", "all checks passed" if ok else "some checks failed (Yahoo may be rate limiting; wait a minute and retry)")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
